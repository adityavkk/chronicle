---
"@durable-streams/client": patch
"@durable-streams/state": patch
---

Add guarded projection snapshot loading, publication, and committed StreamDB bootstrap/export support.

Canonical export requires explicit coherent capture via onCommittedBatch. Without that callback, legacy sync visibility is preserved and exportState rejects rather than pairing queued/stale rows with an advanced cursor.
