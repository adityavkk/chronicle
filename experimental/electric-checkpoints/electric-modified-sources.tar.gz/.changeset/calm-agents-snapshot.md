---
'@electric-ax/agents-runtime': patch
'@electric-ax/agents-server': patch
---

Add opt-in entity projection snapshot recovery and preserve dedicated snapshot mutation credentials through the agents-server proxy. Legacy raw history remains the default; bounded-checkpoint-v1 supports source-derived activation inputs and prefix-skipping recovery from a durable completion checkpoint. Canonical v3 images preserve partial-update merging and inclusive event pointers independently of HTTP batching, with safe-integer-width ordering. Rebuild older experimental images under a fresh projectionVersion; do not mix old-width ordering with new suffix tokens.

Image rotation does not invalidate existing bounded-checkpoint-v1 source progress. Discard disposable streams written by buggy pre-release builds; real-data progress requires an application-level audit/rebuild, not merely a new image codec or projectionVersion.

EntityStreamDB snapshot export requires explicit coherent capture via onCommittedSnapshot; default legacy readers reject export without changing their sync visibility.
