import { access } from 'node:fs/promises'
import path from 'node:path'
import {
  applyElectricUrlQueryParams,
  electricUrlWithPath,
} from './electric-url.js'
import { fetch as undiciFetch } from 'undici'
import { resolveDurableStreamsRoutingAdapter } from '../routing/durable-streams-routing-adapter.js'
import { applyDurableStreamsBearer } from '../stream-client.js'
import type { Agent } from 'undici'
import type { DurableStreamsRoutingAdapter } from '../routing/durable-streams-routing-adapter.js'
import type { DurableStreamsBearerProvider } from '../stream-client.js'

export function contentTypeForStaticFile(filePath: string): string {
  const ext = path.extname(filePath).toLowerCase()
  switch (ext) {
    case `.html`:
      return `text/html; charset=utf-8`
    case `.js`:
      return `text/javascript; charset=utf-8`
    case `.css`:
      return `text/css; charset=utf-8`
    case `.json`:
      return `application/json; charset=utf-8`
    case `.svg`:
      return `image/svg+xml`
    case `.png`:
      return `image/png`
    case `.jpg`:
    case `.jpeg`:
      return `image/jpeg`
    case `.ico`:
      return `image/x-icon`
    case `.map`:
      return `application/json; charset=utf-8`
    default:
      return `application/octet-stream`
  }
}

export function cacheControlForAgentUiFile(filePath: string): string {
  return filePath.includes(`${path.sep}assets${path.sep}`)
    ? `public, max-age=31536000, immutable`
    : `no-cache`
}

export function resolveAgentUiPath(
  agentUiDistDir: string,
  relativePath: string
): string {
  const normalized = relativePath.replace(/^\/+/, ``)
  return path.resolve(agentUiDistDir, normalized)
}

export async function pickAgentUiFile(
  agentUiDistDir: string,
  filePath: string,
  fallbackToIndex: boolean
): Promise<string | null> {
  if (isAgentUiPath(agentUiDistDir, filePath) && (await fileExists(filePath))) {
    return filePath
  }

  if (!fallbackToIndex) {
    return null
  }

  const indexPath = path.join(agentUiDistDir, `index.html`)
  if (!(await fileExists(indexPath))) {
    return null
  }
  return indexPath
}

export function isAgentUiPath(
  agentUiDistDir: string,
  filePath: string
): boolean {
  return (
    filePath === agentUiDistDir ||
    filePath.startsWith(`${agentUiDistDir}${path.sep}`)
  )
}

export async function fileExists(filePath: string): Promise<boolean> {
  try {
    await access(filePath)
    return true
  } catch {
    return false
  }
}

/**
 * Raised when an Electric shape proxy request must be rejected for security
 * reasons (an un-scoped table, or a client `where` clause that could escape the
 * enforced per-tenant/per-principal scoping). The global `errorMapper` hook
 * maps this to an HTTP error response. Defined here (rather than reusing
 * `ElectricAgentsError`) to keep this module free of the heavy entity-manager
 * import graph.
 */
export class ElectricProxyError extends Error {
  constructor(
    readonly code: `INVALID_WHERE` | `TABLE_NOT_ALLOWED`,
    message: string,
    readonly status: number
  ) {
    super(message)
    this.name = `ElectricProxyError`
  }
}

export function buildElectricProxyTarget(options: {
  incomingUrl: URL
  electricUrl: string
  electricSecret?: string
  tenantId: string
  principalUrl?: string
  principalKind?: string
  permissionBypass?: boolean
}): URL {
  const targetPath = options.incomingUrl.pathname.replace(
    `/_electric/electric`,
    ``
  )
  const target = electricUrlWithPath(options.electricUrl, targetPath)
  options.incomingUrl.searchParams.forEach((value, key) => {
    target.searchParams.append(key, value)
  })
  applyElectricUrlQueryParams(target, options.electricUrl)

  if (targetPath !== `/v1/shape`) {
    return target
  }

  if (options.electricSecret) {
    target.searchParams.set(`secret`, options.electricSecret)
  }

  // The enforced scoping `where` is AND-combined with the client's own `where`.
  // A client clause that is not self-contained (e.g. `1=1) OR (1=1`) could
  // break out of its parenthesised group and neutralise the scoping under SQL
  // operator precedence, so reject anything that isn't balanced.
  const clientWhere = options.incomingUrl.searchParams.get(`where`)
  if (clientWhere !== null && !isSelfContainedWhereClause(clientWhere)) {
    throw new ElectricProxyError(`INVALID_WHERE`, `Invalid where clause`, 400)
  }

  const tableParams = options.incomingUrl.searchParams.getAll(`table`)
  if (tableParams.length !== 1) {
    throw new ElectricProxyError(
      `TABLE_NOT_ALLOWED`,
      `Table is not available through the Electric proxy`,
      403
    )
  }

  const table = tableParams[0]
  // Canonicalise the upstream table after validation so duplicate client query
  // params cannot be interpreted differently by Electric or intermediaries.
  target.searchParams.set(`table`, table)

  if (table === `entities`) {
    target.searchParams.set(
      `columns`,
      `"tenant_id","url","type","status","dispatch_policy","tags","spawn_args","sandbox","parent","created_by","type_revision","inbox_schemas","state_schemas","created_at","updated_at"`
    )
    applyShapeWhere(
      target,
      buildReadableEntitiesWhere({
        tenantId: options.tenantId,
        principalUrl: options.principalUrl ?? ``,
        principalKind: options.principalKind ?? ``,
        permissionBypass: options.permissionBypass,
      })
    )
  } else if (table === `entity_types`) {
    target.searchParams.set(
      `columns`,
      `"tenant_id","name","description","creation_schema","inbox_schemas","state_schemas","slash_commands","serve_endpoint","default_dispatch_policy","revision","created_at","updated_at"`
    )
    applyShapeWhere(
      target,
      buildSpawnableEntityTypesWhere({
        tenantId: options.tenantId,
        principalUrl: options.principalUrl ?? ``,
        principalKind: options.principalKind ?? ``,
        permissionBypass: options.permissionBypass,
      })
    )
  } else if (table === `runners`) {
    target.searchParams.set(
      `columns`,
      `"tenant_id","id","owner_principal","label","kind","admin_status","wake_stream","sandbox_profiles","created_at","updated_at"`
    )
    applyTenantShapeWhere(target, options.tenantId, [
      `owner_principal = ${sqlStringLiteral(options.principalUrl ?? ``)}`,
    ])
  } else if (table === `users`) {
    target.searchParams.set(
      `columns`,
      `"tenant_id","id","display_name","email","avatar_url","created_at","updated_at"`
    )
    applyTenantShapeWhere(target, options.tenantId)
  } else if (table === `entity_effective_permissions`) {
    target.searchParams.set(
      `columns`,
      `"tenant_id","id","entity_url","source_entity_url","source_grant_id","permission","subject_kind","subject_value","expires_at","created_at"`
    )
    applyShapeWhere(
      target,
      buildCurrentPrincipalEntityEffectivePermissionsWhere({
        tenantId: options.tenantId,
        principalUrl: options.principalUrl ?? ``,
        principalKind: options.principalKind ?? ``,
        permissionBypass: options.permissionBypass,
      })
    )
  } else if (table === `runner_runtime_diagnostics`) {
    target.searchParams.set(
      `columns`,
      `"tenant_id","runner_id","owner_principal","wake_stream_offset","last_seen_at","liveness_lease_expires_at","diagnostics","updated_at"`
    )
    applyTenantShapeWhere(target, options.tenantId, [
      `owner_principal = ${sqlStringLiteral(options.principalUrl ?? ``)}`,
    ])
  } else if (table === `entity_dispatch_state`) {
    target.searchParams.set(
      `columns`,
      `"tenant_id","entity_url","pending_source_streams","pending_reason","pending_since","outstanding_wake_id","outstanding_wake_target","outstanding_wake_created_at","active_consumer_id","active_runner_id","active_epoch","active_claimed_at","active_lease_expires_at","last_wake_id","last_claimed_at","last_released_at","last_completed_at","last_error","updated_at"`
    )
    applyShapeWhere(
      target,
      buildReadableEntityUrlWhere({
        tenantId: options.tenantId,
        principalUrl: options.principalUrl ?? ``,
        principalKind: options.principalKind ?? ``,
        permissionBypass: options.permissionBypass,
      })
    )
  } else if (table === `wake_notifications`) {
    target.searchParams.set(
      `columns`,
      `"tenant_id","wake_id","entity_url","target_type","target_runner_id","target_webhook_url","target_worker_pool_id","runner_wake_stream","runner_wake_stream_offset","notification_public","delivery_status","claim_status","created_at","delivered_at","claimed_at","resolved_at"`
    )
    applyShapeWhere(
      target,
      buildReadableEntityUrlWhere({
        tenantId: options.tenantId,
        principalUrl: options.principalUrl ?? ``,
        principalKind: options.principalKind ?? ``,
        permissionBypass: options.permissionBypass,
      })
    )
  } else if (table === `consumer_claims`) {
    target.searchParams.set(
      `columns`,
      `"tenant_id","consumer_id","epoch","wake_id","entity_url","stream_path","runner_id","status","claimed_at","last_heartbeat_at","lease_expires_at","released_at","acked_streams","updated_at"`
    )
    applyShapeWhere(
      target,
      buildReadableEntityUrlWhere({
        tenantId: options.tenantId,
        principalUrl: options.principalUrl ?? ``,
        principalKind: options.principalKind ?? ``,
        permissionBypass: options.permissionBypass,
      })
    )
  } else {
    // Default-deny: every shape request gets the privileged Electric secret
    // (when configured) injected above, so only tables with explicit column +
    // row scoping may be proxied. Any other table (or a missing `table` param)
    // is rejected.
    throw new ElectricProxyError(
      `TABLE_NOT_ALLOWED`,
      `Table is not available through the Electric proxy`,
      403
    )
  }

  return target
}

/**
 * Returns true when a client-supplied Electric `where` clause is self-contained:
 * its parentheses are balanced, never close below the top level, all string
 * (`'`) and identifier (`"`) literals are terminated, and it contains no SQL
 * comment markers. Such a clause cannot break out of the `(...)` group it is
 * wrapped in when AND-combined with the enforced scoping predicate, nor comment
 * out the trailing paren the proxy appends. Characters inside string/identifier
 * literals are ignored. Comment markers are rejected unconditionally (even where
 * harmless) as a conservative defensive measure; dollar-quoted and `E''` strings
 * are not modeled and only ever cause fail-safe over-rejection, never a bypass.
 */
function isSelfContainedWhereClause(where: string): boolean {
  let depth = 0
  let quote: `'` | `"` | null = null
  for (let i = 0; i < where.length; i++) {
    const ch = where[i]
    if (quote !== null) {
      if (ch === quote) {
        if (where[i + 1] === quote) {
          i++ // doubled quote is an escaped literal quote
        } else {
          quote = null
        }
      }
      continue
    }
    if (ch === `'` || ch === `"`) {
      quote = ch
    } else if (ch === `(`) {
      depth++
    } else if (ch === `)`) {
      depth--
      if (depth < 0) {
        return false
      }
    } else if (
      (ch === `-` && where[i + 1] === `-`) ||
      (ch === `/` && where[i + 1] === `*`)
    ) {
      return false // SQL comment marker
    }
  }
  return depth === 0 && quote === null
}

export function buildReadableEntitiesWhere(options: {
  tenantId: string
  principalUrl: string
  principalKind: string
  permissionBypass?: boolean
}): string {
  const tenant = sqlStringLiteral(options.tenantId)
  if (options.permissionBypass) {
    return `tenant_id = ${tenant}`
  }
  const principalUrl = sqlStringLiteral(options.principalUrl)
  const principalKind = sqlStringLiteral(options.principalKind)
  return [
    `tenant_id = ${tenant}`,
    `AND (`,
    `  created_by = ${principalUrl}`,
    `  OR url IN (`,
    `    SELECT entity_url`,
    `    FROM entity_effective_permissions`,
    `    WHERE tenant_id = ${tenant}`,
    `      AND permission IN ('read', 'manage')`,
    `      AND (`,
    `        (subject_kind = 'principal' AND subject_value = ${principalUrl})`,
    `        OR (subject_kind = 'principal_kind' AND subject_value = ${principalKind})`,
    `      )`,
    `  )`,
    `)`,
  ].join(`\n`)
}

export function buildReadableEntityUrlWhere(options: {
  tenantId: string
  principalUrl: string
  principalKind: string
  permissionBypass?: boolean
}): string {
  const tenant = sqlStringLiteral(options.tenantId)
  if (options.permissionBypass) {
    return `tenant_id = ${tenant}`
  }
  return [
    `tenant_id = ${tenant}`,
    `AND entity_url IN (`,
    `  SELECT url`,
    `  FROM entities`,
    `  WHERE ${indentWhere(
      buildReadableEntitiesWhere(options),
      `    `
    ).trimStart()}`,
    `)`,
  ].join(`\n`)
}

export function buildCurrentPrincipalEntityEffectivePermissionsWhere(options: {
  tenantId: string
  principalUrl: string
  principalKind: string
  permissionBypass?: boolean
}): string {
  const tenant = sqlStringLiteral(options.tenantId)
  if (options.permissionBypass) {
    return `tenant_id = ${tenant}`
  }
  const principalUrl = sqlStringLiteral(options.principalUrl)
  const principalKind = sqlStringLiteral(options.principalKind)
  return [
    `tenant_id = ${tenant}`,
    `AND (`,
    `  (subject_kind = 'principal' AND subject_value = ${principalUrl})`,
    `  OR (subject_kind = 'principal_kind' AND subject_value = ${principalKind})`,
    `)`,
    `AND entity_url IN (`,
    `  SELECT url`,
    `  FROM entities`,
    `  WHERE ${buildReadableEntitiesWhere(options)}`,
    `)`,
  ].join(`\n`)
}

export function buildSpawnableEntityTypesWhere(options: {
  tenantId: string
  principalUrl: string
  principalKind: string
  permissionBypass?: boolean
}): string {
  const tenant = sqlStringLiteral(options.tenantId)
  if (options.permissionBypass) {
    return `tenant_id = ${tenant}`
  }
  const principalUrl = sqlStringLiteral(options.principalUrl)
  const principalKind = sqlStringLiteral(options.principalKind)
  return [
    `tenant_id = ${tenant}`,
    `AND name IN (`,
    `  SELECT entity_type`,
    `  FROM entity_type_permission_grants`,
    `  WHERE tenant_id = ${tenant}`,
    `    AND permission IN ('spawn', 'manage')`,
    `    AND (`,
    `      (subject_kind = 'principal' AND subject_value = ${principalUrl})`,
    `      OR (subject_kind = 'principal_kind' AND subject_value = ${principalKind})`,
    `    )`,
    `)`,
  ].join(`\n`)
}

export async function forwardFetchRequest(options: {
  request: {
    method: string
    url: string
    headers: Headers
  }
  durableStreamsUrl: string
  durableStreamsRouting?: DurableStreamsRoutingAdapter
  serviceId: string
  body?: Uint8Array
  dispatcher?: Agent
  route?: `stream` | `control`
  durableStreamsBearer?: DurableStreamsBearerProvider
  durableStreamsBearerMode?: `overwrite` | `if-missing` | `none`
}): Promise<Response> {
  const routingAdapter = resolveDurableStreamsRoutingAdapter(
    options.durableStreamsRouting,
    options.durableStreamsUrl
  )
  const routingInput = {
    durableStreamsUrl: options.durableStreamsUrl,
    serviceId: options.serviceId,
    requestUrl: options.request.url,
  }
  const upstreamUrl =
    options.route === `control`
      ? routingAdapter.controlUrl(routingInput)
      : routingAdapter.streamUrl(routingInput)

  const headers = new Headers(options.request.headers)
  if (options.durableStreamsBearerMode !== `none`) {
    await applyDurableStreamsBearer(headers, options.durableStreamsBearer, {
      overwrite: options.durableStreamsBearerMode !== `if-missing`,
    })
  }

  const init: RequestInit & { duplex?: `half`; dispatcher?: Agent } = {
    method: options.request.method,
    headers,
  }
  if (options.body !== undefined) {
    headers.delete(`content-length`)
    init.body = bodyFromBytes(options.body)
    init.duplex = `half`
  }
  if (options.dispatcher) {
    init.dispatcher = options.dispatcher
    return (await undiciFetch(
      upstreamUrl,
      init as Parameters<typeof undiciFetch>[1]
    )) as unknown as Response
  }

  return await fetch(upstreamUrl, init)
}

function bodyFromBytes(body: Uint8Array): ArrayBuffer {
  return body.buffer.slice(
    body.byteOffset,
    body.byteOffset + body.byteLength
  ) as ArrayBuffer
}

export function decodeJsonObject(
  body: Uint8Array
): Record<string, unknown> | null {
  if (body.length === 0) return null

  try {
    const parsed = JSON.parse(new TextDecoder().decode(body)) as unknown
    if (parsed && typeof parsed === `object` && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>
    }
  } catch {
    // Not JSON; callers can fall back to raw bytes.
  }

  return null
}

function applyTenantShapeWhere(
  target: URL,
  tenantId: string,
  extraConditions: Array<string> = []
): void {
  applyShapeWhere(
    target,
    [`tenant_id = ${sqlStringLiteral(tenantId)}`, ...extraConditions].join(
      ` AND `
    )
  )
}

function applyShapeWhere(target: URL, enforcedWhere: string): void {
  const existingWhere = target.searchParams.get(`where`)
  target.searchParams.set(
    `where`,
    existingWhere ? `${enforcedWhere} AND (${existingWhere})` : enforcedWhere
  )
}

function sqlStringLiteral(value: string): string {
  return `'${value.replace(/'/g, `''`)}'`
}

function indentWhere(where: string, prefix: string): string {
  return where
    .split(`\n`)
    .map((line) => `${prefix}${line}`)
    .join(`\n`)
}
