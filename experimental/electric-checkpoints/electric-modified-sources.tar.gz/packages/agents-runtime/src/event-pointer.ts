/**
 * `EventPointer` addresses a single event on a Durable Stream.
 *
 * It is the pair the agents-server uses on the wire when forking: it
 * maps directly to the `Stream-Fork-Offset` + `Stream-Fork-Sub-Offset`
 * headers in the Durable Streams protocol.
 *
 * Semantics:
 *
 *   - `offset` is the anchor offset on the source stream. `null` means
 *     "anchor at stream start" (sent as an explicit zero offset; an omitted
 *     HTTP fork offset defaults to tail, not stream start).
 *   - `subOffset` is the count of JSON messages past the anchor to
 *     include in the fork. So sub-offset `N` includes items
 *     `[0, 1, ... N-1]` of the flattened JSON history after `offset`, across
 *     physical append entries.
 *
 * A pointer addresses inclusively-through-and-stops-at-item-(subOffset-1).
 * For "fork up to and including item at source-index `j`," set
 * `subOffset = j + 1`.
 *
 * Why this shape and not the wire's opaque offset alone:
 * the protocol ships fork-side sub-offsets but does NOT add read-side
 * sub-offsets — the wire never tells the client the sub-offset of a
 * delivered item. EntityStreamDB uses a canonical null anchor plus cumulative
 * source-item count (including controls and unknown items). Projection image
 * v3 persists that count with safe-integer-width order tokens, so a hydrated
 * suffix produces the same pointer and timeline ordering as full replay
 * regardless of HTTP grouping. Late forks
 * can consequently scan more source history than an entry-local anchor.
 */
export interface EventPointer {
  /** Anchor offset on the source stream, or `null` for stream-start. */
  offset: string | null
  /**
   * Count of JSON messages past `offset` to include — sub-offset N
   * includes items `[0 .. N-1]`. For "include item at index j," set
   * `subOffset = j + 1`.
   */
  subOffset: number
}

/**
 * v3 widths for canonical pointer ordering.
 *
 * `OFFSET_WIDTH` is the legacy pad width used by `_timeline_order`.
 * The sub-offset now represents a whole-stream cumulative count, so its
 * width covers Number.MAX_SAFE_INTEGER. v1/v2 images used eight digits and
 * must be rejected/rebuilt under a fresh projectionVersion, not mixed with
 * widened suffix tokens. OFFSET_WIDTH stays at its legacy value.
 */
const OFFSET_WIDTH = 24
const SUB_OFFSET_WIDTH = 16

/**
 * The token prefix that signals "this row was sourced from a stream
 * event" (as opposed to a pending optimistic row, a `_seq`-based
 * fallback, etc.). Kept identical to the previous single-offset
 * format so existing `like(_timeline_order, 'stream:...')` queries keep
 * matching after the upgrade.
 */
export const STREAM_TOKEN_PREFIX = `stream:`

/**
 * Format an `EventPointer` as a lexicographically-sortable token for
 * use in `_timeline_order` / `__electricRowOffsets`-derived ordering.
 *
 * The format is:
 *
 *   `stream:<zero-padded-offset>:<zero-padded-subOffset>`
 *
 * - Empty / null offsets zero-pad to all-zeros, which sorts before any
 *   non-empty offset — correct, since the first batch of a fresh read
 *   has `offset === null` and its items must sort before later batches.
 * - Higher offset → sorts later. Within the same offset, higher
 *   sub-offset → sorts later. Net: strict monotonic order matching
 *   the stream's order.
 */
export function formatPointerOrderToken(pointer: EventPointer): string {
  if (!Number.isSafeInteger(pointer.subOffset) || pointer.subOffset < 0) {
    throw new Error(
      `Event pointer subOffset must be a nonnegative safe integer`
    )
  }
  const paddedOffset = (pointer.offset ?? ``).padStart(OFFSET_WIDTH, `0`)
  const paddedSubOffset = pointer.subOffset
    .toString()
    .padStart(SUB_OFFSET_WIDTH, `0`)
  return `${STREAM_TOKEN_PREFIX}${paddedOffset}:${paddedSubOffset}`
}

/**
 * Compare two pointers in stream order.
 *
 *   - returns `< 0` if `left` precedes `right`
 *   - returns `> 0` if `left` follows `right`
 *   - returns `0` if they address the same event
 *
 * Compares lexicographically on the order-token form so the relation
 * agrees with `_timeline_order`'s string sort.
 */
export function comparePointers(
  left: EventPointer,
  right: EventPointer
): number {
  const leftToken = formatPointerOrderToken(left)
  const rightToken = formatPointerOrderToken(right)
  if (leftToken < rightToken) return -1
  if (leftToken > rightToken) return 1
  return 0
}

/**
 * The stream-start pointer — zero items past a null anchor. Used as
 * the initial accumulator when iterating a fresh stream from the
 * beginning before any batches have arrived.
 */
export const STREAM_START_POINTER: EventPointer = {
  offset: null,
  subOffset: 0,
}
