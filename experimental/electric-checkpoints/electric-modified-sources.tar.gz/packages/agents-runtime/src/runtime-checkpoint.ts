import type { EntityProjectionImageV3 } from './entity-stream-db'
import type { RuntimeCheckpoint } from './entity-schema'

export const RUNTIME_CHECKPOINT_KEY = `bounded-checkpoint-v1`

/** Only a fully drained prefix is representable without a raw pending ledger. */
export function hasUnresolvedCheckpointWork(
  image: EntityProjectionImageV3
): boolean {
  return (
    (image.rowsByCollection.inbox ?? []).some(
      (row) =>
        row.status === `pending` &&
        (row.mode === `queued` || row.mode === `paused`)
    ) ||
    (image.rowsByCollection.signals ?? []).some(
      (row) => row.status === `unhandled`
    )
  )
}

/**
 * A bounded image ends at the single checkpoint event immediately following
 * its drained state cut. Requiring adjacency detects concurrent input before
 * or after the marker without inventing completion from batch/ack cursors.
 */
export function checkpointFromImage(
  image: EntityProjectionImageV3
): RuntimeCheckpoint | null {
  const checkpoint = (image.rowsByCollection.runtimeCheckpoints ?? []).find(
    (row) => row.key === RUNTIME_CHECKPOINT_KEY
  ) as RuntimeCheckpoint | undefined
  if (
    !checkpoint ||
    checkpoint.contract !== RUNTIME_CHECKPOINT_KEY ||
    typeof checkpoint.processedThrough !== `string` ||
    checkpoint.processedThrough === `-1` ||
    checkpoint.processedThrough >= image.offset ||
    !Number.isSafeInteger(checkpoint.processedSeq) ||
    checkpoint.processedSeq < 0 ||
    checkpoint._seq !== checkpoint.processedSeq ||
    image.nextSeq !== checkpoint.processedSeq + 1 ||
    hasUnresolvedCheckpointWork(image)
  ) {
    return null
  }
  return checkpoint
}
