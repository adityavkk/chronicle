import { createHash, randomUUID } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { afterAll, describe, expect, it, vi } from 'vitest'
import { DurableStream } from '@durable-streams/client'
import { z } from 'zod'
import { runtimeTest } from './runtime-dsl'
import { startChronicleGate } from './chronicle-e2e-gate'
import { checkpointFromImage } from '../src/runtime-checkpoint'
import {
  createEntityStreamDB,
  decodeEntityProjectionImage,
} from '../src/entity-stream-db'
import { entity as entitySource } from '../src/observation-sources'
import type {
  EntityProjectionImageV3,
  StateCollectionProxy,
  WakeMetrics,
} from '../src/index'

const enabled = Boolean(
  process.env.CHRONICLE_STREAM_ROOT &&
    process.env.CHRONICLE_TOKEN_DIR &&
    process.env.CHRONICLE_CALLBACK_GATE_URL
)
const root = enabled ? new URL(process.env.CHRONICLE_STREAM_ROOT!) : null
const callbackRoot = enabled
  ? new URL(process.env.CHRONICLE_CALLBACK_GATE_URL!)
  : null
for (const url of [root, callbackRoot]) {
  if (url && ![`127.0.0.1`, `localhost`, `::1`].includes(url.hostname))
    throw new Error(`Refusing non-loopback checkpoint fixture`)
}
const token = enabled
  ? (
      await readFile(`${process.env.CHRONICLE_TOKEN_DIR}/.writer-token`, `utf8`)
    ).trim()
  : ``
const publisher = enabled
  ? (
      await readFile(
        `${process.env.CHRONICLE_TOKEN_DIR}/.publisher-token`,
        `utf8`
      )
    ).trim()
  : ``
const gate = root ? await startChronicleGate(root) : null
const suite = enabled ? describe : describe.skip
const version = `checkpoint-real-e2e-v1`
const rowSchema = z.object({ key: z.string(), inputs: z.array(z.string()) })
type Row = z.infer<typeof rowSchema>

function latch() {
  let release!: () => void
  const promise = new Promise<void>((resolve) => {
    release = resolve
  })
  return { promise, release }
}

suite(`real bounded runtime checkpoint recovery`, () => {
  const metrics = new Map<string, Array<WakeMetrics>>()
  const inputs = new Map<string, Array<Array<string>>>()
  const selfObservationInputs = new Map<string, Array<Array<string>>>()
  const attempts = new Map<string, number>()
  const canceled = new Set<string>()
  const blocks = new Map<
    string,
    { started: ReturnType<typeof latch>; resume: ReturnType<typeof latch> }
  >()
  let nextWebhookHold: {
    arrived: ReturnType<typeof latch>
    resume: ReturnType<typeof latch>
  } | null = null
  const runtime = runtimeTest({
    durableStreamsUrl: (
      gate?.streamRoot ?? `http://127.0.0.1:1/v1/stream/`
    ).replace(/\/$/, ``),
    durableStreamsBearer: token,
    rawInputRecovery: `bounded-checkpoint-v1`,
    projectionSnapshots: {
      projectionVersion: version,
      rawInputRecovery: `bounded-checkpoint-v1`,
      publisherHeaders: () => ({ authorization: `Bearer ${publisher}` }),
      minReplayEvents: 0,
      minReplayMs: 0,
      minPublishIntervalMs: 0,
      missBackoffMs: 0,
    },
    resetBackend: false,
    onWakeMetrics(value) {
      const list = metrics.get(value.entityUrl) ?? []
      list.push(value)
      metrics.set(value.entityUrl, list)
    },
    async beforeWebhook() {
      if (!nextWebhookHold) return
      const hold = nextWebhookHold
      nextWebhookHold = null
      hold.arrived.release()
      await hold.resume.promise
    },
  })
  const rawInputs = (events: Array<{ type: string; value?: unknown }>) =>
    events
      .filter((event) => event.type === `inbox`)
      .map(
        (event) => (event.value as { payload?: { id?: string } })?.payload?.id
      )
      .filter((id): id is string => typeof id === `string`)
  runtime.define(`e2e`, {
    state: { rows: { schema: rowSchema, primaryKey: `key` } },
    async handler(ctx) {
      const self = await ctx.observe(entitySource(ctx.entityUrl))
      const list = selfObservationInputs.get(ctx.entityUrl) ?? []
      list.push(rawInputs(self.events))
      selfObservationInputs.set(ctx.entityUrl, list)
      const delta = rawInputs(ctx.events)
      const observed = inputs.get(ctx.entityUrl) ?? []
      observed.push(delta)
      inputs.set(ctx.entityUrl, observed)
      if (delta.includes(`cancel-block`) && canceled.has(ctx.entityUrl)) return
      const block = blocks.get(ctx.entityUrl)
      if (
        (delta.includes(`block`) ||
          delta.includes(`sleep-block`) ||
          delta.includes(`cancel-block`)) &&
        block
      ) {
        block.started.release()
        await Promise.race([
          block.resume.promise,
          new Promise<void>((resolve) =>
            ctx.signal.addEventListener(`abort`, () => resolve(), {
              once: true,
            })
          ),
        ])
        if (ctx.signal.aborted) {
          canceled.add(ctx.entityUrl)
          return
        }
      }
      if (delta.includes(`fail-once`)) {
        const attempt = (attempts.get(ctx.entityUrl) ?? 0) + 1
        attempts.set(ctx.entityUrl, attempt)
        if (attempt === 1)
          throw new Error(`intentional checkpoint handler failure`)
      }
      const rows = (ctx.state as { rows: StateCollectionProxy<Row> }).rows
      const current = rows.get(`main`)
      if (current)
        rows.update(`main`, (draft) => {
          draft.inputs.push(...delta)
        })
      else rows.insert({ key: `main`, inputs: delta })
      if (delta.length) ctx.replyText(delta.join(`,`))
      if (delta.includes(`sleep-block`) && !delta.includes(`pending-B`))
        ctx.sleep()
    },
  })
  const disposables: Array<{ path: string; subscription: string }> = []
  const waitForWake = async (entityUrl: string, count: number) => {
    const deadline = Date.now() + 90_000
    while (
      (metrics.get(entityUrl)?.length ?? 0) < count &&
      Date.now() < deadline
    )
      await new Promise((resolve) => setTimeout(resolve, 5))
    expect(metrics.get(entityUrl)?.length ?? 0).toBeGreaterThanOrEqual(count)
  }
  const fixture = async (initial = `one`) => {
    const id = `checkpoint-${randomUUID()}`
    const entity = await runtime.spawn(
      `e2e`,
      id,
      {},
      { initialMessage: { id: initial } }
    )
    const path = `e2e/${id}/main`
    const subscription = `webhook:e2e:${createHash(`sha256`).update(entity.entityUrl).digest(`hex`).slice(0, 16)}`
    disposables.push({ path, subscription })
    await waitForWake(entity.entityUrl, 1)
    await entity.waitForSettled(30_000)
    const stream = new DurableStream({
      url: new URL(path, root!).toString(),
      headers: { authorization: `Bearer ${token}` },
      contentType: `application/json`,
    })
    let image = await stream.loadSnapshot(version)
    for (let attempt = 0; !image && attempt < 100; attempt++) {
      await new Promise((resolve) => setTimeout(resolve, 10))
      image = await stream.loadSnapshot(version)
    }
    expect(image).not.toBeNull()
    expect(
      checkpointFromImage(JSON.parse(new TextDecoder().decode(image!.body)))
    ).not.toBeNull()
    return { entity, stream, path, subscription, image: image! }
  }

  const ack = async (subscription: string, path: string) => {
    const response = await fetch(
      new URL(`__ds/subscriptions/${encodeURIComponent(subscription)}`, root!),
      { headers: { authorization: `Bearer ${token}` } }
    )
    expect(response.status).toBe(200)
    const body = (await response.json()) as {
      streams: Array<{ path: string; acked_offset: string }>
    }
    return body.streams.find((item) => item.path === path)?.acked_offset
  }
  const assertAck = async (f: Awaited<ReturnType<typeof fixture>>) => {
    const head = await f.stream.head()
    expect(head.exists).toBe(true)
    const expected = head.exists ? head.offset : null
    const deadline = Date.now() + 30_000
    let actual = await ack(f.subscription, f.path)
    while (actual !== expected && Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 5))
      actual = await ack(f.subscription, f.path)
    }
    expect(actual).toBe(expected)
  }
  const noPrefix = (
    image: { offset: string; incarnation: string },
    requests: typeof gate extends null
      ? never
      : Array<{
          method: string
          pathname: string
          snapshot: string | null
          search: string
          incarnationGuard: string | null
        }>,
    path: string
  ) => {
    const reads = requests.filter(
      (request) =>
        request.method === `GET` &&
        request.snapshot === null &&
        request.pathname.endsWith(`/${path}`)
    )
    expect(reads.length).toBeGreaterThan(0)
    expect(new URLSearchParams(reads[0]!.search).get(`offset`)).toBe(
      image.offset
    )
    for (const request of reads) {
      const offset = new URLSearchParams(request.search).get(`offset`)
      expect(offset).not.toBeNull()
      expect(offset! >= image.offset).toBe(true)
      expect(request.incarnationGuard).toBe(image.incarnation)
    }
    return reads.length
  }

  afterAll(async () => {
    nextWebhookHold?.resume.release()
    for (const block of blocks.values()) block.resume.release()
    for (const disposable of disposables) {
      const response = await fetch(
        new URL(
          `__ds/subscriptions/${encodeURIComponent(disposable.subscription)}`,
          root!
        ),
        { method: `DELETE`, headers: { authorization: `Bearer ${token}` } }
      )
      expect([200, 204, 404]).toContain(response.status)
    }
    await runtime.cleanup()
    for (const disposable of disposables)
      await new DurableStream({
        url: new URL(disposable.path, root!).toString(),
        headers: { authorization: `Bearer ${token}` },
      }).delete()
    await gate?.stop()
  }, 60_000)

  it(`restores deletes, bounds raw/self-observation inputs, and rejects forged progress`, async () => {
    const f = await fixture()
    const server = await runtime.getServerUrl()
    const forged = await fetch(`${server}/${f.path}`, {
      method: `POST`,
      headers: { 'content-type': `application/json` },
      body: JSON.stringify({
        type: `runtime_checkpoint`,
        key: `bounded-checkpoint-v1`,
        value: {
          contract: `bounded-checkpoint-v1`,
          processedSeq: 999999,
          processedThrough: `now`,
        },
        headers: { operation: `upsert` },
      }),
    })
    expect(forged.status).toBe(401)
    await f.stream.append(
      [
        {
          type: `state:rows`,
          key: `deleted`,
          value: { key: `deleted`, inputs: [`gone`] },
          headers: { operation: `insert` },
        },
        {
          type: `state:rows`,
          key: `deleted`,
          headers: { operation: `delete` },
        },
      ]
        .map((event) => JSON.stringify(event))
        .join(`,`)
    )
    await f.entity.waitForSettled(30_000)
    const image = await f.stream.loadSnapshot(version)
    expect(
      (
        JSON.parse(
          new TextDecoder().decode(image!.body)
        ) as EntityProjectionImageV3
      ).rowsByCollection.rows.map((row) => row.key)
    ).toEqual([`main`])
    gate!.reset()
    const capture = gate!.startCapture()
    const wakeCount = metrics.get(f.entity.entityUrl)!.length
    await f.entity.send({
      id: `two`,
      type: `runtime_checkpoint`,
      value: { processedSeq: 999999, processedThrough: `now` },
    })
    await waitForWake(f.entity.entityUrl, wakeCount + 1)
    const requests = capture.stop()
    const history = await f.entity.waitForSettled(30_000)
    expect(inputs.get(f.entity.entityUrl)).toEqual([[`one`], [`two`]])
    expect(selfObservationInputs.get(f.entity.entityUrl)?.at(-1)).toEqual([
      `two`,
    ])
    const main = history.events
      .filter((event) => event.type === `state:rows` && event.key === `main`)
      .at(-1)?.value as Row
    expect(main.inputs).toEqual([`one`, `two`])
    expect(
      history.events
        .filter((event) => event.type === `text_delta`)
        .map((event) => (event.value as { delta: string }).delta)
    ).toEqual([`one`, `two`])
    await assertAck(f)
    const prefixFreeReads = noPrefix(image!, requests, f.path)
    process.stdout.write(
      `${JSON.stringify({ kind: `checkpoint-e2e`, case: `deletes-and-marker-trust`, prefixFreeReads, assertions: { state: true, rawInputs: true, selfObservationInputs: true, persistedOutput: true, ack: true, forgedMarkerRejected: true, nestedPayloadIgnored: true, noPrefixReads: true } })}\n`
    )
  }, 60_000)

  it(`forks the exact inclusive prefix from a restored v2 pointer including controls`, async () => {
    const f = await fixture()
    await assertAck(f)
    const image = decodeEntityProjectionImage(f.image.body, version)
    await f.stream.append(
      [
        { headers: { control: `snapshot-start` } },
        {
          type: `state:rows`,
          key: `fork-target`,
          value: { inputs: [`target`] },
          headers: { operation: `insert` },
        },
        { headers: { control: `snapshot-end` } },
      ]
        .map((event) => JSON.stringify(event))
        .join(`,`)
    )
    await waitForWake(f.entity.entityUrl, 2)
    const hydrated = createEntityStreamDB(
      new URL(f.path, root!).toString(),
      { rows: { schema: rowSchema, primaryKey: `key` } },
      undefined,
      {
        onCommittedSnapshot: () => {},
        snapshot: { image, incarnation: f.image.incarnation },
        streamOptions: { headers: { authorization: `Bearer ${token}` } },
      }
    )
    const fork = new DurableStream({
      url: new URL(
        `e2e/checkpoint-fork-${randomUUID()}/main`,
        root!
      ).toString(),
      headers: { authorization: `Bearer ${token}` },
    })
    try {
      await hydrated.preload()
      const pointer =
        hydrated.collections.rows.__electricRowOffsets!.get(`fork-target`)!
      const latest = hydrated.utils.exportSnapshot(version)
      expect(latest.nextEventPosition).toBeGreaterThan(latest.nextSeq)
      expect(pointer.offset).toBeNull()
      const history = await f.entity.history()
      const expected = history.events.slice(0, pointer.subOffset)
      expect(expected.at(-1)?.key).toBe(`fork-target`)
      expect(
        expected.some((event) => event.headers?.control === `snapshot-start`)
      ).toBe(true)
      const created = await fetch(fork.url, {
        method: `PUT`,
        headers: {
          authorization: `Bearer ${token}`,
          'content-type': `application/json`,
          'Stream-Forked-From': new URL(f.path, root!).pathname,
          'Stream-Fork-Offset': `0000000000000000_0000000000000000`,
          'Stream-Fork-Sub-Offset': String(pointer.subOffset),
        },
      })
      expect(created.status).toBe(201)
      const actual = await (
        await fork.stream({ offset: `-1`, live: false })
      ).json()
      expect(actual).toEqual(expected)
      process.stdout.write(
        `${JSON.stringify({ kind: `checkpoint-e2e`, case: `restored-canonical-fork`, pointer, assertions: { exactInclusivePrefix: true, controlItemCounted: true, stateRestored: true } })}\n`
      )
    } finally {
      hydrated.close()
      await fork.delete()
    }
  }, 60_000)

  it(`restores a pending cold signal and observes live cancellation after a hit`, async () => {
    const f = await fixture()
    await assertAck(f)
    const hold = { arrived: latch(), resume: latch() }
    nextWebhookHold = hold
    await f.entity.send({ id: `after-signal` })
    await hold.arrived.promise
    await runtime.signal(f.entity.entityUrl, `SIGUSR`, {
      reason: `pending checkpoint signal`,
    })
    hold.resume.release()
    await waitForWake(f.entity.entityUrl, 2)
    await assertAck(f)
    const pendingHistory = await f.entity.history()
    expect(
      pendingHistory.events.filter((event) => event.type === `signal`).at(-1)
        ?.value
    ).toMatchObject({ signal: `SIGUSR`, status: `handled` })
    expect(inputs.get(f.entity.entityUrl)?.at(-1)).toEqual([`after-signal`])
    const block = { started: latch(), resume: latch() }
    blocks.set(f.entity.entityUrl, block)
    await f.entity.send({ id: `cancel-block` })
    await block.started.promise
    await runtime.signal(f.entity.entityUrl, `SIGINT`, {
      reason: `checkpoint live cancellation`,
    })
    await waitForWake(f.entity.entityUrl, 3)
    // The cancellation disposition is idempotent if a callback fault later
    // redelivers it; no exactly-once external side-effect claim is made.
    block.resume.release()
    const history = await f.entity.history()
    expect(
      history.events.filter((event) => event.type === `signal`).at(-1)?.value
    ).toMatchObject({ signal: `SIGINT`, status: `handled`, outcome: `aborted` })
    expect(
      history.events
        .filter((event) => event.type === `text_delta`)
        .map((event) => (event.value as { delta: string }).delta)
    ).toEqual([`one`, `after-signal`])
    await assertAck(f)
    process.stdout.write(
      `${JSON.stringify({ kind: `checkpoint-e2e`, case: `pending-signal-live-cancellation`, assertions: { signal: true, cancellation: true, persistedOutput: true, ack: true }, exactlyOnceExternalEffectsClaimed: false })}\n`
    )
  }, 120_000)

  it(`recovers concurrent fresh work without moving progress past it`, async () => {
    const f = await fixture()
    const block = { started: latch(), resume: latch() }
    blocks.set(f.entity.entityUrl, block)
    await f.entity.send({ id: `block` })
    await block.started.promise
    await f.entity.send({ id: `concurrent` })
    block.resume.release()
    const history = await f.entity.waitForSettled(30_000)
    expect(inputs.get(f.entity.entityUrl)).toEqual([
      [`one`],
      [`block`],
      [`concurrent`],
    ])
    expect(
      (
        history.events
          .filter(
            (event) => event.type === `state:rows` && event.key === `main`
          )
          .at(-1)?.value as Row
      ).inputs
    ).toEqual([`one`, `block`, `concurrent`])
    await assertAck(f)
    process.stdout.write(
      `${JSON.stringify({ kind: `checkpoint-e2e`, case: `concurrent-append`, assertions: { state: true, rawInputs: true, ack: true } })}\n`
    )
  }, 60_000)

  it(`never acks producer output past B when A replies and sleeps`, async () => {
    const f = await fixture()
    await assertAck(f)
    const priorAck = await ack(f.subscription, f.path)
    const block = { started: latch(), resume: latch() }
    blocks.set(f.entity.entityUrl, block)
    await fetch(new URL(`/__fixture/records`, callbackRoot!), {
      method: `DELETE`,
    })
    await f.entity.send({ id: `sleep-block` })
    await block.started.promise
    await f.entity.send({ id: `pending-B` })
    const bHead = await f.stream.head()
    const hold = { arrived: latch(), resume: latch() }
    nextWebhookHold = hold
    block.resume.release()
    await hold.arrived.promise
    try {
      const afterA = await f.stream.head()
      expect(
        afterA.exists && bHead.exists && afterA.offset! > bHead.offset!
      ).toBe(true)
      expect(await ack(f.subscription, f.path)).toBe(priorAck)
      expect((await f.stream.loadSnapshot(version))?.offset).toBe(
        f.image.offset
      )
      const records = (await (
        await fetch(new URL(`/__fixture/records`, callbackRoot!))
      ).json()) as Array<{
        done: boolean
        status: number
        acks: Array<unknown>
      }>
      expect(
        records.find((record) => record.done && record.status === 200)?.acks
      ).toEqual([])
      expect(inputs.get(f.entity.entityUrl)).toEqual([[`one`], [`sleep-block`]])
    } finally {
      hold.resume.release()
    }
    await waitForWake(f.entity.entityUrl, 3)
    await f.entity.waitForSettled(60_000)
    expect(inputs.get(f.entity.entityUrl)?.at(-1)).toEqual([
      `sleep-block`,
      `pending-B`,
    ])
    await assertAck(f)
    process.stdout.write(
      `${JSON.stringify({ kind: `checkpoint-e2e`, case: `A-sleeps-B-pending`, assertions: { noAckPastPending: true, checkpointDeclined: true, BRedelivered: true, rawInputs: true, ack: true }, exactlyOnceExternalEffectsClaimed: false })}\n`
    )
  }, 120_000)

  it(`does not run or ack on a claim transport denial and recovers real redelivery`, async () => {
    const f = await fixture()
    await assertAck(f)
    const priorAck = await ack(f.subscription, f.path)
    // Electric answers claims locally, so route the unchanged claim HTTP
    // request through a transparent fixture proxy at that actual boundary.
    const server = await runtime.getServerUrl()
    const claimProxy = await startChronicleGate(new URL(`${server}/`))
    claimProxy.failNext((request) => request.method === `POST`, 401)
    const originalFetch = globalThis.fetch
    const transport = vi
      .spyOn(globalThis, `fetch`)
      .mockImplementation((input, init) => {
        const url = new URL(
          typeof input === `string`
            ? input
            : input instanceof URL
              ? input.href
              : input.url
        )
        if (
          url.pathname.includes(`/wake-callbacks/`) &&
          typeof init?.body === `string` &&
          typeof JSON.parse(init.body).wakeId === `string`
        ) {
          url.host = new URL(claimProxy.streamRoot).host
          return originalFetch(url, init)
        }
        return originalFetch(input, init)
      })
    try {
      await f.entity.send({ id: `denied` })
      await claimProxy.waitFor((request) => request.status === 401, 10_000)
      expect(inputs.get(f.entity.entityUrl)).toEqual([[`one`]])
      expect(await ack(f.subscription, f.path)).toBe(priorAck)
    } finally {
      transport.mockRestore()
      await claimProxy.stop()
    }
    await waitForWake(f.entity.entityUrl, 2)
    expect(inputs.get(f.entity.entityUrl)).toEqual([[`one`], [`denied`]])
    await assertAck(f)
    process.stdout.write(
      `${JSON.stringify({ kind: `checkpoint-e2e`, case: `denied-claim-redelivery`, assertions: { noHandlerBeforeClaim: true, noAckBeforeClaim: true, exactInputs: true, ack: true } })}\n`
    )
  }, 120_000)

  it(`includes input arriving during a claim transport stall in the bounded delta`, async () => {
    const f = await fixture()
    await assertAck(f)
    const capture = gate!.startCapture()
    const claimStarted = latch()
    const claimRelease = latch()
    const originalFetch = globalThis.fetch
    const transport = vi
      .spyOn(globalThis, `fetch`)
      .mockImplementation(async (input, init) => {
        const url =
          typeof input === `string`
            ? input
            : input instanceof URL
              ? input.href
              : input.url
        if (
          url.includes(`/wake-callbacks/`) &&
          typeof init?.body === `string` &&
          typeof JSON.parse(init.body).wakeId === `string`
        ) {
          claimStarted.release()
          await claimRelease.promise
        }
        return originalFetch(input, init)
      })
    try {
      await f.entity.send({ id: `delayed-A` })
      await claimStarted.promise
      expect(inputs.get(f.entity.entityUrl)).toEqual([[`one`]])
      await f.entity.send({ id: `delayed-B` })
      const bHead = await f.stream.head()
      if (!bHead.exists || !bHead.offset)
        throw new Error(`Fixture stream missing`)
      // Wait until the real source reader, running concurrently with claim,
      // has observed B before releasing the unchanged actual claim request.
      await gate!.waitFor(
        (request) =>
          request.method === `GET` &&
          request.pathname.endsWith(`/${f.path}`) &&
          request.streamNextOffset !== null &&
          request.streamNextOffset >= bHead.offset!,
        10_000
      )
    } finally {
      claimRelease.release()
      transport.mockRestore()
    }
    await waitForWake(f.entity.entityUrl, 2)
    const requests = capture.stop()
    expect(inputs.get(f.entity.entityUrl)).toEqual([
      [`one`],
      [`delayed-A`, `delayed-B`],
    ])
    await assertAck(f)
    noPrefix(f.image, requests, f.path)
    process.stdout.write(
      `${JSON.stringify({ kind: `checkpoint-e2e`, case: `delayed-claim-interleaving`, assertions: { exactInputs: true, noPrefixReads: true, noHandlerBeforeClaim: true, ack: true } })}\n`
    )
  }, 60_000)

  it(`releases without ack on a guarded suffix read failure before successful retry`, async () => {
    const f = await fixture()
    await assertAck(f)
    const priorAck = await ack(f.subscription, f.path)
    await fetch(new URL(`/__fixture/records`, callbackRoot!), {
      method: `DELETE`,
    })
    gate!.failNext(
      (request) =>
        request.method === `GET` &&
        request.pathname.endsWith(`/${f.path}`) &&
        new URLSearchParams(request.search).get(`snapshot`) === null,
      412
    )
    runtime.expectWakeError(/412|incarnation/)
    await f.entity.send({ id: `guarded` })
    await waitForWake(f.entity.entityUrl, 2)
    expect(metrics.get(f.entity.entityUrl)!.at(-1)?.succeeded).toBe(false)
    expect(inputs.get(f.entity.entityUrl)).toEqual([[`one`]])
    expect(await ack(f.subscription, f.path)).toBe(priorAck)
    const records = (await (
      await fetch(new URL(`/__fixture/records`, callbackRoot!))
    ).json()) as Array<{ done: boolean; status: number; acks: Array<unknown> }>
    expect(
      records.find((record) => record.done && record.status === 200)?.acks
    ).toEqual([])
    await waitForWake(f.entity.entityUrl, 3)
    expect(inputs.get(f.entity.entityUrl)).toEqual([[`one`], [`guarded`]])
    await assertAck(f)
    process.stdout.write(
      `${JSON.stringify({ kind: `checkpoint-e2e`, case: `guard-rejection-redelivery`, assertions: { noHandlerOnGuardFailure: true, noAckOnGuardFailure: true, exactInputs: true, ack: true } })}\n`
    )
  }, 120_000)

  it(`does not checkpoint or ack failed work and preserves automatic redelivery`, async () => {
    const f = await fixture()
    runtime.expectWakeError(/intentional checkpoint handler failure/)
    await f.entity.send({ id: `fail-once` })
    await f.entity.waitForTypeCount(`text_delta`, 1, {
      timeoutMs: 90_000,
      predicate: (event) =>
        (event.value as { delta?: string })?.delta === `fail-once`,
    })
    await f.entity.waitForSettled(30_000)
    expect(attempts.get(f.entity.entityUrl)).toBe(2)
    expect(inputs.get(f.entity.entityUrl)).toEqual([
      [`one`],
      [`fail-once`],
      [`fail-once`],
    ])
    await assertAck(f)
    process.stdout.write(
      `${JSON.stringify({ kind: `checkpoint-e2e`, case: `failure-redelivery`, handlerAttempts: 2, exactlyOnceExternalEffectsClaimed: false, assertions: { state: true, rawInputs: true, ack: true } })}\n`
    )
  }, 120_000)

  it(`retains durable completion when the actual done callback fails`, async () => {
    const f = await fixture()
    await fetch(new URL(`/__fixture/records`, callbackRoot!), {
      method: `DELETE`,
    })
    expect(
      (
        await fetch(new URL(`/__fixture/fail-next-done`, callbackRoot!), {
          method: `POST`,
        })
      ).status
    ).toBe(204)
    runtime.expectWakeError(/Done callback failed \(503\)/)
    await f.entity.send({ id: `saved` })
    const deadline = Date.now() + 90_000
    while (
      (metrics.get(f.entity.entityUrl)?.length ?? 0) < 3 &&
      Date.now() < deadline
    )
      await new Promise((resolve) => setTimeout(resolve, 20))
    expect(metrics.get(f.entity.entityUrl)?.length).toBeGreaterThanOrEqual(3)
    await f.entity.waitForSettled(30_000)
    expect(inputs.get(f.entity.entityUrl)).toEqual([[`one`], [`saved`]])
    const history = await f.entity.history()
    expect(
      history.events
        .filter((event) => event.type === `text_delta`)
        .map((event) => (event.value as { delta: string }).delta)
    ).toEqual([`one`, `saved`])
    await assertAck(f)
    const callbacks = (await (
      await fetch(new URL(`/__fixture/records`, callbackRoot!))
    ).json()) as Array<{ done: boolean; status: number }>
    expect(
      callbacks.some((record) => record.done && record.status === 503)
    ).toBe(true)
    expect(
      callbacks.some((record) => record.done && record.status === 200)
    ).toBe(true)
    process.stdout.write(
      `${JSON.stringify({ kind: `checkpoint-e2e`, case: `saved-before-done-failure`, exactlyOnceExternalEffectsClaimed: false, assertions: { state: true, rawInputs: true, persistedOutput: true, ack: true, durableRedeliverySkipped: true } })}\n`
    )
  }, 120_000)
})
