import { describe, expect, it, vi } from 'vitest'
import { createEntityStreamDB } from '../src/entity-stream-db'
import {
  checkpointFromImage,
  RUNTIME_CHECKPOINT_KEY,
} from '../src/runtime-checkpoint'

async function project(events: Array<unknown>) {
  const db = createEntityStreamDB(
    `http://127.0.0.1:1/entity`,
    { notes: {} } as any,
    undefined,
    {
      onCommittedSnapshot: () => {},
      streamOptions: {
        fetch: vi.fn<typeof fetch>().mockResolvedValue(
          new Response(JSON.stringify(events), {
            headers: {
              'content-type': `application/json`,
              'stream-next-offset': `20`,
              'stream-up-to-date': `true`,
            },
          })
        ),
      },
    }
  )
  await db.preload()
  const image = db.utils.exportSnapshot(`bounded-test-v1`)
  db.close()
  return image
}

const change = (
  type: string,
  key: string,
  value: unknown,
  operation = `insert`
) => ({
  type,
  key,
  value,
  headers: { operation },
})
const marker = (processedSeq: number) =>
  change(`runtime_checkpoint`, RUNTIME_CHECKPOINT_KEY, {
    contract: RUNTIME_CHECKPOINT_KEY,
    processedThrough: `10`,
    processedSeq,
  })

describe(`bounded checkpoint source alignment`, () => {
  it(`retains deletes and requires the marker immediately after its drained prefix`, async () => {
    const image = await project([
      change(`state:notes`, `a`, { text: `retained` }),
      change(`state:notes`, `b`, { text: `deleted` }),
      change(`state:notes`, `b`, undefined, `delete`),
      marker(3),
    ])
    expect(image.rowsByCollection.notes.map((row) => row.key)).toEqual([`a`])
    expect(checkpointFromImage(image)).toMatchObject({
      processedSeq: 3,
      processedThrough: `10`,
      _seq: 3,
    })
  })

  it.each([`before`, `after`])(
    `declines a fresh input %s the marker instead of suppressing it`,
    async (position) => {
      const input = change(`inbox`, `b`, {
        payload: `pending B`,
        status: `pending`,
        mode: `queued`,
        timestamp: `2026-01-01`,
      })
      const image = await project(
        position === `before` ? [input, marker(0)] : [marker(0), input]
      )
      expect(checkpointFromImage(image)).toBeNull()
    }
  )

  it(`does not turn same-batch A completion into B completion`, async () => {
    const image = await project([
      change(`inbox`, `a`, {
        payload: `A`,
        status: `processed`,
        mode: `queued`,
        timestamp: `2026-01-01`,
      }),
      change(`inbox`, `b`, {
        payload: `B`,
        status: `pending`,
        mode: `queued`,
        timestamp: `2026-01-01`,
      }),
      marker(2),
    ])
    expect(checkpointFromImage(image)).toBeNull()
    expect(
      image.rowsByCollection.inbox.find((row) => row.key === `b`)?.status
    ).toBe(`pending`)
  })

  it(`rejects a paused inbox or an unresolved signal despite otherwise aligned progress`, async () => {
    for (const event of [
      change(`inbox`, `paused`, {
        payload: `later`,
        status: `pending`,
        mode: `paused`,
        timestamp: `2026-01-01`,
      }),
      change(`signal`, `sig`, {
        signal: `SIGINT`,
        status: `unhandled`,
        timestamp: `2026-01-01`,
      }),
    ]) {
      expect(checkpointFromImage(await project([event, marker(1)]))).toBeNull()
    }
  })
})
