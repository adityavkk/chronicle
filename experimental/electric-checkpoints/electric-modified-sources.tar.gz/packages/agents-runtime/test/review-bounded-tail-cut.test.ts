import { expect, it, vi } from 'vitest'
import { DurableStreamTestServer } from '@durable-streams/server'
import { DurableStream } from '@durable-streams/client'
import { processWake } from '../src/process-wake'
import { clearRegistry, defineEntity } from '../src/define-entity'
import { createEntityStreamDB } from '../src/entity-stream-db'
import { checkpointFromImage } from '../src/runtime-checkpoint'
import type { WebhookNotification } from '../src/types'
import { ev } from './helpers/event-fixtures'

it.each([true, false])(
  `does not skip an unseen input below the notification tail (stamped=%s)`,
  async (stamped) => {
    clearRegistry()
    const server = new DurableStreamTestServer({ port: 0 })
    const baseUrl = await server.start()
    const streamPath = `/streams/two-inputs`
    const stream = await DurableStream.create({
      url: `${baseUrl}${streamPath}`,
      contentType: `application/json`,
    })
    const delivered: Array<Array<string>> = []
    const done: Array<any> = []
    defineEntity(`review`, {
      handler: (ctx) => {
        delivered.push(
          ctx.events.filter((e) => e.type === `inbox`).map((e) => String(e.key))
        )
        ctx.sleep()
      },
    })
    const originalFetch = globalThis.fetch
    vi.spyOn(globalThis, `fetch`).mockImplementation(async (input, init) => {
      const url =
        typeof input === `string`
          ? input
          : input instanceof URL
            ? input.href
            : input.url
      if (url === `http://callback.test/tail`) {
        const body = JSON.parse(String(init?.body))
        if (body.done) done.push(body)
        return Response.json({ ok: true, writeToken: `test` })
      }
      const response = await originalFetch(input, init)
      if (
        !stamped &&
        url.startsWith(`${baseUrl}${streamPath}`) &&
        response.headers.get(`content-type`)?.includes(`application/json`) &&
        (init?.method ?? `GET`) === `GET`
      ) {
        const events = (await response.json()) as Array<{
          headers: Record<string, unknown>
        }>
        for (const event of events) delete event.headers.offset
        const headers = new Headers(response.headers)
        headers.delete(`content-length`)
        return new Response(JSON.stringify(events), {
          status: response.status,
          headers,
        })
      }
      return response
    })
    try {
      await stream.append(
        JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
      )
      const aHead = await stream.head()
      if (!aHead.exists || !aHead.offset)
        throw new Error(`Fixture stream missing`)
      const aOffset = aHead.offset
      await stream.append(
        JSON.stringify(ev(`inbox`, `b`, `insert`, { payload: `B` }))
      )
      const bHead = await stream.head()
      if (!bHead.exists || !bHead.offset)
        throw new Error(`Fixture stream missing`)
      const bOffset = bHead.offset
      const notification: WebhookNotification = {
        consumerId: `review`,
        epoch: 1,
        wakeId: `review-tail`,
        streamPath,
        streams: [{ path: streamPath, offset: bOffset }],
        callback: `http://callback.test/tail`,
        claimToken: `test`,
        entity: {
          type: `review`,
          url: `/review/entity`,
          status: `active`,
          streams: { main: streamPath },
        },
      }
      await processWake(notification, {
        baseUrl,
        idleTimeout: 0,
        heartbeatInterval: 1_000_000,
        rawInputRecovery: `bounded-checkpoint-v1`,
      })
      const db = createEntityStreamDB(
        `${baseUrl}${streamPath}`,
        undefined,
        undefined,
        {
          onCommittedSnapshot: () => {},
        }
      )
      await db.preload()
      const image = db.utils.exportSnapshot(`review-v1`)
      db.close()
      console.log(
        `TAIL_CUT_REPRO`,
        JSON.stringify({
          aOffset,
          bOffset,
          delivered,
          checkpoint: checkpointFromImage(image),
          done,
        })
      )
      // The handler consumes the entire delta it actually receives. Both inputs
      // are canonical and neither has any previous checkpoint proving completion.
      expect(delivered).toEqual([[`a`, `b`]])
    } finally {
      vi.restoreAllMocks()
      await server.stop()
    }
  },
  10_000
)
