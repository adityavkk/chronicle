import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { DurableStreamTestServer } from '@durable-streams/server'
import { DurableStream } from '@durable-streams/client'
import { processWake } from '../src/process-wake'
import { clearRegistry, defineEntity } from '../src/define-entity'
import {
  createEntityStreamDB,
  encodeEntityProjectionImage,
} from '../src/entity-stream-db'
import { checkpointFromImage } from '../src/runtime-checkpoint'
import type { WebhookNotification, ProcessWakeConfig } from '../src/types'
import { ev } from './helpers/event-fixtures'

let server: DurableStreamTestServer
let baseUrl: string
let stream: DurableStream
let doneBodies: Array<any>
let config: ProcessWakeConfig
const streamPath = `/streams/review2`
const callback = `http://callback.test/wake`

async function notification(epoch = 1): Promise<WebhookNotification> {
  const head = await stream.head()
  if (!head.exists || !head.offset) throw new Error(`Fixture stream missing`)
  return {
    consumerId: `review`,
    epoch,
    wakeId: `review2-${epoch}`,
    streamPath,
    streams: [{ path: streamPath, offset: head.offset! }],
    callback,
    claimToken: `test`,
    entity: {
      type: `review2`,
      url: `/review2/entity`,
      status: `active`,
      streams: { main: streamPath },
    },
  }
}

beforeEach(async () => {
  clearRegistry()
  server = new DurableStreamTestServer({ port: 0 })
  baseUrl = await server.start()
  stream = await DurableStream.create({
    url: `${baseUrl}${streamPath}`,
    contentType: `application/json`,
  })
  doneBodies = []
  const realFetch = globalThis.fetch
  vi.spyOn(globalThis, `fetch`).mockImplementation(async (input, init) => {
    const url =
      typeof input === `string`
        ? input
        : input instanceof URL
          ? input.href
          : input.url
    if (url === callback) {
      const body = JSON.parse(String(init?.body))
      if (body.done) doneBodies.push(body)
      return Response.json({ ok: true, writeToken: `test` })
    }
    return realFetch(input, init)
  })
  config = {
    baseUrl,
    idleTimeout: 0,
    heartbeatInterval: 1_000_000,
    rawInputRecovery: `bounded-checkpoint-v1`,
  }
})

afterEach(async () => {
  vi.restoreAllMocks()
  await server.stop()
})

it(`retries a queued input after its handler failed during promotion`, async () => {
  const delivered: string[] = []
  let fail = true
  defineEntity(`review2`, {
    handler: (ctx, wake) => {
      delivered.push(String(wake.payload))
      if (fail) {
        fail = false
        throw new Error(`handler failed`)
      }
      ctx.sleep()
    },
  })
  await stream.append(
    JSON.stringify(
      ev(`inbox`, `a`, `insert`, {
        payload: `A`,
        mode: `queued`,
        status: `pending`,
      })
    )
  )
  await expect(processWake(await notification(), config)).rejects.toThrow(
    `handler failed`
  )
  expect(doneBodies.at(-1).acks).toEqual([])
  await processWake(await notification(2), config)
  expect(delivered).toEqual([`A`, `A`])
})

it(`retains certified handler completion despite later sandbox cleanup failure`, async () => {
  let failDispose = true
  let calls = 0
  defineEntity(`review2`, {
    handler: (ctx) => {
      calls++
      if (failDispose) {
        failDispose = false
        vi.spyOn(ctx.sandbox, `dispose`).mockRejectedValueOnce(
          new Error(`dispose failed`)
        )
      }
      ctx.sleep()
    },
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
  )
  await expect(processWake(await notification(), config)).rejects.toThrow(
    `dispose failed`
  )
  expect(doneBodies.at(-1).acks).toEqual([])
  const replay = createEntityStreamDB(
    `${baseUrl}${streamPath}`,
    undefined,
    undefined,
    {
      onCommittedSnapshot: () => {},
    }
  )
  await replay.preload()
  const image = replay.utils.exportSnapshot(`review2`)
  replay.close()
  await processWake(await notification(2), config)
  console.log(
    `DISPOSE_AFTER_MARKER`,
    JSON.stringify({
      doneBodies,
      calls,
      checkpoint: checkpointFromImage(image),
    })
  )
  expect(checkpointFromImage(image)).not.toBeNull()
  expect(calls).toBe(1)
  expect(doneBodies.at(-1).acks).toHaveLength(1)
})

it(`encodes identical canonical rows for same-key writes across HTTP batches`, async () => {
  const changes = [
    ev(`state:notes`, `a`, `insert`, { x: 1, y: 2 }),
    ev(`state:notes`, `b`, `insert`, { z: 3 }),
    ev(`state:notes`, `a`, `update`, { x: 4, q: 5 }),
    { type: `state:notes`, key: `b`, headers: { operation: `delete` } },
    ev(`state:notes`, `b`, `insert`, { r: 6 }),
    ev(`state:notes`, `a`, `update`, { nested: { yes: true } }),
  ]
  async function project(groups: any[][]) {
    let next = 0
    const db = createEntityStreamDB(
      `https://example.test/rows`,
      { notes: {} } as any,
      undefined,
      {
        onCommittedSnapshot: () => {},
        streamOptions: {
          fetch: async (_input, init) => {
            const group = groups[next++]
            if (!group)
              return new Promise<Response>((_resolve, reject) =>
                init?.signal?.addEventListener(`abort`, () =>
                  reject(new DOMException(`Aborted`, `AbortError`))
                )
              )
            return new Response(JSON.stringify(group), {
              headers: {
                'content-type': `application/json`,
                'stream-next-offset':
                  next === groups.length ? `99` : `0${next}`,
                ...(next === groups.length
                  ? { 'stream-up-to-date': `true` }
                  : {}),
              },
            })
          },
        },
      }
    )
    await db.preload()
    const image = db.utils.exportSnapshot(`review2`)
    db.close()
    return image
  }
  const single = await project([changes])
  const split = await project(changes.map((change) => [change]))
  console.log(
    `ROW_GROUPING`,
    JSON.stringify({
      single: single.rowsByCollection.notes,
      split: split.rowsByCollection.notes,
    })
  )
  expect(new TextDecoder().decode(encodeEntityProjectionImage(single))).toBe(
    new TextDecoder().decode(encodeEntityProjectionImage(split))
  )
})

it(`retains B appended immediately before the checkpoint request`, async () => {
  const delivered: string[][] = []
  defineEntity(`review2`, {
    handler: (ctx) => {
      delivered.push(
        ctx.events.filter((e) => e.type === `inbox`).map((e) => String(e.key))
      )
      ctx.sleep()
    },
  })
  const priorFetch = vi.mocked(globalThis.fetch).getMockImplementation()!
  let injected = false
  vi.spyOn(globalThis, `fetch`).mockImplementation(async (input, init) => {
    if (
      !injected &&
      init?.method === `POST` &&
      String(init.body).includes(`runtime_checkpoint`)
    ) {
      injected = true
      await stream.append(
        JSON.stringify(ev(`inbox`, `b`, `insert`, { payload: `B` }))
      )
    }
    return priorFetch(input, init)
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
  )
  await processWake(await notification(), config)
  expect(injected).toBe(true)
  expect(delivered).toEqual([[`a`]])
  expect(doneBodies.at(-1).acks).toEqual([])
  await processWake(await notification(2), config)
  expect(delivered).toEqual([[`a`], [`b`]])
  expect(doneBodies.at(-1).acks).toHaveLength(1)
})

it(`delivers B that arrives while a successful claim is delayed`, async () => {
  const delivered: string[][] = []
  defineEntity(`review2`, {
    handler: (ctx) => {
      delivered.push(
        ctx.events.filter((e) => e.type === `inbox`).map((e) => String(e.key))
      )
      ctx.sleep()
    },
  })
  const priorFetch = vi.mocked(globalThis.fetch).getMockImplementation()!
  let startClaim!: () => void
  let releaseClaim!: () => void
  const claimStarted = new Promise<void>((resolve) => {
    startClaim = resolve
  })
  const claimHeld = new Promise<void>((resolve) => {
    releaseClaim = resolve
  })
  vi.spyOn(globalThis, `fetch`).mockImplementation(async (input, init) => {
    if (String(input) === callback && JSON.parse(String(init?.body)).wakeId) {
      startClaim()
      await claimHeld
    }
    return priorFetch(input, init)
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
  )
  const activation = processWake(await notification(), config)
  await claimStarted
  await stream.append(
    JSON.stringify(ev(`inbox`, `b`, `insert`, { payload: `B` }))
  )
  await new Promise((resolve) => setTimeout(resolve, 50))
  expect(delivered).toEqual([])
  releaseClaim()
  await activation
  expect(delivered).toEqual([[`a`, `b`]])
  expect(doneBodies.at(-1).acks).toHaveLength(1)
})

it(`forks the exact v3 prefix counting controls across real append entries`, async () => {
  const history = [
    { headers: { control: `snapshot-start` } },
    ev(`state:notes`, `a`, `insert`, { text: `A` }),
    { headers: { control: `snapshot-end` } },
    ev(`state:notes`, `b`, `insert`, { text: `B` }),
    ev(`state:notes`, `decoy`, `insert`, { text: `do not fork this` }),
  ]
  for (const event of history) await stream.append(JSON.stringify(event))
  const db = createEntityStreamDB(
    `${baseUrl}${streamPath}`,
    {
      notes: {},
    } as any,
    undefined,
    { onCommittedSnapshot: () => {} }
  )
  await db.preload()
  const image = db.utils.exportSnapshot(`review3`)
  const pointer = db.collections.notes.__electricRowOffsets!.get(`b`)!
  db.close()
  expect(image.nextSeq).toBe(3)
  expect(image.nextEventPosition).toBe(5)
  expect(pointer).toEqual({ offset: null, subOffset: 4 })
  const fork = await DurableStream.create({
    url: `${baseUrl}/streams/fork`,
    contentType: `application/json`,
    headers: {
      'Stream-Forked-From': streamPath,
      'Stream-Fork-Offset': `0000000000000000_0000000000000000`,
      'Stream-Fork-Sub-Offset': String(pointer.subOffset),
    },
  })
  const forked = await (await fork.stream({ live: false })).json<any>()
  // The fork restamps offsets in its own source coordinate system.
  expect(
    forked.map(({ headers: { offset: _offset, ...headers }, ...event }) => ({
      ...event,
      headers,
    }))
  ).toEqual(history.slice(0, 4))
})

it(`exports canonical image bytes after tracked applyEvent insertion/update echoes`, async () => {
  let liveImage:
    | ReturnType<
        ReturnType<typeof createEntityStreamDB>[`utils`][`exportSnapshot`]
      >
    | undefined
  defineEntity(`review2`, {
    state: { notes: {} },
    handler: async (ctx) => {
      const exportSnapshot = ctx.db.utils.exportSnapshot
      ctx.db.utils.exportSnapshot = (version) => {
        const image = exportSnapshot(version)
        if (checkpointFromImage(image)) liveImage = image
        return image
      }
      await ctx.db.utils.applyEvent(
        ev(`state:notes`, `a`, `insert`, { text: `same canonical row` })
      ).isPersisted.promise
      expect(ctx.db.collections.notes.get(`a`)?._timeline_order).toBe(
        `stream:000000000000000000000000:0000000000000002`
      )
      await ctx.db.utils.applyEvent(
        ev(`state:notes`, `a`, `update`, { text: `updated canonical row` })
      ).isPersisted.promise
      // The current pointer advances, but stable ordering remains at the
      // canonical FIRST insertion, not the update or its provisional token.
      expect(ctx.db.collections.notes.get(`a`)?._timeline_order).toBe(
        `stream:000000000000000000000000:0000000000000002`
      )
      expect(ctx.db.utils.exportSnapshot(`review4`).rowPointers.notes).toEqual([
        [`a`, { offset: null, subOffset: 3 }],
      ])
      ctx.sleep()
    },
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `start`, `insert`, { payload: `start` }))
  )
  await processWake(await notification(), config)
  expect(doneBodies.at(-1).acks).toHaveLength(1)
  expect(liveImage).toBeDefined()
  const replay = createEntityStreamDB(
    `${baseUrl}${streamPath}`,
    {
      notes: {},
    } as any,
    undefined,
    { onCommittedSnapshot: () => {} }
  )
  await replay.preload()
  const replayImage = replay.utils.exportSnapshot(`bounded-checkpoint-v1`)
  replay.close()
  expect(liveImage!.offset).toBe(replayImage.offset)
  expect(liveImage!.rowPointers).toEqual(replayImage.rowPointers)
  console.log(
    `APPLY_EVENT_CANONICAL_IMAGE`,
    JSON.stringify({
      live: liveImage!.rowsByCollection.notes,
      replay: replayImage.rowsByCollection.notes,
      liveOrder: liveImage!.timelineOrders.notes,
      replayOrder: replayImage.timelineOrders.notes,
    })
  )
  expect(
    new TextDecoder().decode(encodeEntityProjectionImage(liveImage!))
  ).toBe(new TextDecoder().decode(encodeEntityProjectionImage(replayImage)))
})

it(`keeps pending optimistic metadata out of canonical indexes and preserves canonical arrival order`, async () => {
  await stream.append(
    JSON.stringify(ev(`inbox`, `start`, `insert`, { payload: `start` }))
  )
  let release!: () => void
  let queued!: () => void
  const held = new Promise<void>((resolve) => {
    release = resolve
  })
  const written = new Promise<void>((resolve) => {
    queued = resolve
  })
  const pendingWrites: Array<string> = []
  const db = createEntityStreamDB(
    `${baseUrl}${streamPath}`,
    { notes: {} } as any,
    undefined,
    {
      writeEvent: (event) => {
        pendingWrites.push(JSON.stringify(event))
        queued()
      },
      flushWrites: async () => {
        await held
        await stream.append(pendingWrites.splice(0).join(`,`))
      },
      onCommittedSnapshot: () => {},
    }
  )
  await db.preload()
  const committedImage = db.utils.exportSnapshot(`review4`)
  const transaction = db.utils.applyEvent(
    ev(`state:notes`, `a`, `insert`, { text: `optimistic A` })
  )
  await written
  try {
    // At the unchanged committed cut, neither the optimistic row nor its
    // provisional index may alter exported bytes.
    const pendingImage = db.utils.exportSnapshot(`review4`)
    expect(
      new TextDecoder().decode(encodeEntityProjectionImage(pendingImage))
    ).toBe(
      new TextDecoder().decode(encodeEntityProjectionImage(committedImage))
    )
    await stream.append(
      JSON.stringify(
        ev(`state:notes`, `b`, `insert`, { text: `canonical B first` })
      )
    )
    await vi.waitFor(
      () =>
        expect(db.collections.notes.__electricTimelineOrders!.has(`b`)).toBe(
          true
        ),
      { timeout: 5_000 }
    )
    const pendingBImage = db.utils.exportSnapshot(`review4`)
    expect(pendingBImage.rowsByCollection.notes.map((row) => row.key)).toEqual([
      `b`,
    ])
    expect(pendingBImage.timelineOrders.notes).toEqual([
      [`b`, `stream:000000000000000000000000:0000000000000002`],
    ])
    expect(pendingBImage.rowPointers.notes).toEqual([
      [`b`, { offset: null, subOffset: 2 }],
    ])
  } catch (error) {
    release()
    await transaction.isPersisted.promise
    db.close()
    throw error
  }
  release()
  await transaction.isPersisted.promise
  const image = db.utils.exportSnapshot(`review4`)
  db.close()
  expect(image.timelineOrders.notes).toEqual([
    [`b`, `stream:000000000000000000000000:0000000000000002`],
    [`a`, `stream:000000000000000000000000:0000000000000003`],
  ])
  const replay = createEntityStreamDB(
    `${baseUrl}${streamPath}`,
    {
      notes: {},
    } as any,
    undefined,
    { onCommittedSnapshot: () => {} }
  )
  await replay.preload()
  const replayImage = replay.utils.exportSnapshot(`review4`)
  replay.close()
  expect(image.offset).toBe(replayImage.offset)
  expect(new TextDecoder().decode(encodeEntityProjectionImage(image))).toBe(
    new TextDecoder().decode(encodeEntityProjectionImage(replayImage))
  )
}, 15_000)
