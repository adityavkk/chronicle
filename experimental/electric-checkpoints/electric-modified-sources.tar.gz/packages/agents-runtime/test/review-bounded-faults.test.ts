import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import type { MockInstance } from 'vitest'
import { DurableStreamTestServer } from '@durable-streams/server'
import { DurableStream } from '@durable-streams/client'
import { processWake } from '../src/process-wake'
import { clearRegistry, defineEntity } from '../src/define-entity'
import {
  createEntityStreamDB,
  encodeEntityProjectionImage,
} from '../src/entity-stream-db'
import { WakeRegistry } from '../../agents-server/src/wake-registry'
import type { WebhookNotification, ProcessWakeConfig } from '../src/types'
import { ev } from './helpers/event-fixtures'

let server: DurableStreamTestServer
let baseUrl: string
let stream: DurableStream
let doneBodies: Array<any>
let config: ProcessWakeConfig
const streamPath = `/streams/review-faults`
const callback = `http://callback.test/wake`

async function sourceOffset() {
  const head = await stream.head()
  if (!head.exists || !head.offset) throw new Error(`Fixture stream missing`)
  return head.offset
}

function notification(offset: string): WebhookNotification {
  return {
    consumerId: `review`,
    epoch: 1,
    wakeId: `review-fault`,
    streamPath,
    streams: [{ path: streamPath, offset }],
    callback,
    claimToken: `test`,
    entity: {
      type: `review`,
      url: `/review/entity`,
      status: `active`,
      streams: { main: streamPath },
    },
  }
}

beforeEach(async () => {
  clearRegistry()
  server = new DurableStreamTestServer({ port: 0 })
  baseUrl = await server.start()
  stream = await DurableStream.create({
    url: `${baseUrl}${streamPath}`,
    contentType: `application/json`,
  })
  doneBodies = []
  const originalFetch = globalThis.fetch
  vi.spyOn(globalThis, `fetch`).mockImplementation(async (input, init) => {
    const url =
      typeof input === `string`
        ? input
        : input instanceof URL
          ? input.href
          : input.url
    if (url === callback) {
      const body = JSON.parse(String(init?.body))
      if (body.done) doneBodies.push(body)
      return Response.json({ ok: true, writeToken: `test` })
    }
    return originalFetch(input, init)
  })
  config = {
    baseUrl,
    idleTimeout: 0,
    heartbeatInterval: 1_000_000,
    rawInputRecovery: `bounded-checkpoint-v1`,
  }
})

afterEach(async () => {
  vi.restoreAllMocks()
  await server.stop()
})

it(`releases the claim without ack after a batch failure during cleanup`, async () => {
  let dispose: MockInstance<(opts?: { reclaim?: boolean }) => Promise<void>>
  defineEntity(`review`, {
    handler: async (ctx) => {
      dispose = vi.spyOn(ctx.sandbox, `dispose`)
      const drain = ctx.db.utils.drainPendingWrites
      let drains = 0
      ctx.db.utils.drainPendingWrites = async () => {
        await drain()
        if (++drains === 2) {
          // The first drain runs after the handler. The second is inside finally.
          await stream.append(
            JSON.stringify({
              type: `unknown-type`,
              key: `x`,
              value: {},
              headers: { operation: `insert` },
            })
          )
          await vi.waitFor(() =>
            expect(() => ctx.db.exportState()).toThrow(`failed stream batch`)
          )
        }
      }
      ctx.sleep()
    },
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
  )
  await expect(
    processWake(notification(await sourceOffset()), config)
  ).rejects.toThrow(
    /failed stream batch|Wake failed during processing or cleanup/
  )
  console.log(
    `CLEANUP_REPRO`,
    JSON.stringify({ doneBodies, sandboxDisposals: dispose!.mock.calls.length })
  )
  expect(doneBodies).toEqual([{ epoch: 1, acks: [], done: true }])
  expect(dispose!).toHaveBeenCalledOnce()
}, 10_000)

it(`retains durable completion after sandbox disposal fails without ack`, async () => {
  const delivered: Array<Array<string>> = []
  defineEntity(`review`, {
    handler: (ctx) => {
      delivered.push(
        ctx.events
          .filter((event) => event.type === `inbox`)
          .map((event) => String(event.key))
      )
      ctx.replyText(`completed A`)
      vi.spyOn(ctx.sandbox, `dispose`).mockRejectedValueOnce(
        new Error(`disposal failed`)
      )
    },
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
  )
  const aOffset = await sourceOffset()
  await expect(processWake(notification(aOffset), config)).rejects.toThrow(
    `disposal failed`
  )
  expect(doneBodies).toEqual([{ epoch: 1, acks: [], done: true }])
  const history = await (
    await stream.stream({ offset: `-1`, live: false })
  ).json<any>()
  expect(
    history.filter((event) => event.type === `runtime_checkpoint`)
  ).toHaveLength(1)
  const retry = notification(aOffset)
  retry.epoch = 2
  retry.wakeId = `review-fault-retry`
  await processWake(retry, config)
  expect(delivered).toEqual([[`a`]])
  expect(doneBodies.at(-1)).toEqual({
    epoch: 2,
    acks: [{ path: streamPath, offset: await sourceOffset() }],
    done: true,
  })
  const finalHistory = await (
    await stream.stream({ offset: `-1`, live: false })
  ).json<any>()
  expect(
    finalHistory
      .filter((event) => event.type === `text_delta`)
      .map((event) => event.value.delta)
  ).toEqual([`completed A`])
}, 10_000)

it(`preserves Electric partial update fields even in legacy full replay`, async () => {
  defineEntity(`review`, {
    handler: (ctx) => {
      ctx.sleep()
    },
  })
  await stream.append(
    JSON.stringify(
      ev(`inbox`, `a`, `insert`, {
        payload: `A`,
        status: `pending`,
        mode: `queued`,
      })
    )
  )
  await processWake(notification(await sourceOffset()), {
    ...config,
    rawInputRecovery: `full-replay`,
  })
  const replay = createEntityStreamDB(`${baseUrl}${streamPath}`)
  await replay.preload()
  const inbox = replay.collections.inbox.get(`a`)
  replay.close()
  console.log(`PARTIAL_UPDATE_REPRO`, JSON.stringify({ inbox }))
  expect(inbox?.status).toBe(`processed`)
  expect(inbox?.payload).toBe(`A`)
  expect(inbox?.mode).toBe(`queued`)
}, 10_000)

it(`does not convert runtime progress into a runnable self-observation wake`, async () => {
  const mockDb = {
    insert: () => ({
      values: () => ({
        onConflictDoNothing: () => ({ returning: async () => [{ id: 1 }] }),
      }),
    }),
  }
  const registry = new WakeRegistry(mockDb as any)
  await registry.register({
    subscriberUrl: `/review/entity`,
    sourceUrl: `/review/entity`,
    condition: { on: `change` },
    oneShot: false,
  })
  const result = registry.evaluate(`/review/entity`, {
    type: `runtime_checkpoint`,
    key: `bounded-checkpoint-v1`,
    headers: { operation: `upsert` },
    value: {
      contract: `bounded-checkpoint-v1`,
      processedThrough: `10`,
      processedSeq: 1,
    },
  })
  console.log(`SELF_WAKE_REPRO`, JSON.stringify(result))
  expect(result).toEqual([])
})

it(`exports identical prefix bytes independent of HTTP grouping for unstamped events`, async () => {
  const a = {
    type: `state:notes`,
    key: `a`,
    value: { text: `A` },
    headers: { operation: `insert` },
  }
  const b = {
    type: `state:notes`,
    key: `b`,
    value: { text: `B` },
    headers: { operation: `insert` },
  }
  const marker = {
    type: `runtime_checkpoint`,
    key: `bounded-checkpoint-v1`,
    headers: { operation: `upsert` },
    value: {
      contract: `bounded-checkpoint-v1`,
      processedThrough: `10`,
      processedSeq: 2,
    },
  }
  async function project(groups: Array<{ items: any[]; offset: string }>) {
    let n = 0
    const db = createEntityStreamDB(
      `https://example.test/grouping`,
      { notes: {} } as any,
      undefined,
      {
        onCommittedSnapshot: () => {},
        streamOptions: {
          fetch: async (_input, init) => {
            const group = groups[n++]
            if (!group)
              return new Promise<Response>((_resolve, reject) =>
                init?.signal?.addEventListener(`abort`, () =>
                  reject(new DOMException(`Aborted`, `AbortError`))
                )
              )
            return new Response(JSON.stringify(group.items), {
              headers: {
                'content-type': `application/json`,
                'stream-next-offset': group.offset,
                ...(n === groups.length ? { 'stream-up-to-date': `true` } : {}),
              },
            })
          },
        },
      }
    )
    await db.preload()
    const image = db.utils.exportSnapshot(`review-v1`)
    db.close()
    return image
  }
  const single = await project([
    { items: structuredClone([a, b, marker]), offset: `20` },
  ])
  const split = await project([
    { items: structuredClone([a]), offset: `05` },
    { items: structuredClone([b, marker]), offset: `20` },
  ])
  console.log(
    `GROUPING_REPRO`,
    JSON.stringify({
      single: single.rowPointers.notes,
      split: split.rowPointers.notes,
    })
  )
  expect(single.nextSeq).toBe(split.nextSeq)
  expect(single.offset).toBe(split.offset)
  expect(new TextDecoder().decode(encodeEntityProjectionImage(single))).toBe(
    new TextDecoder().decode(encodeEntityProjectionImage(split))
  )
}, 10_000)
