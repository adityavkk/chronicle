import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { DurableStreamTestServer } from '@durable-streams/server'
import { DurableStream } from '@durable-streams/client'
import { processWake } from '../src/process-wake'
import { clearRegistry, defineEntity } from '../src/define-entity'
import type { WebhookNotification, ProcessWakeConfig } from '../src/types'
import { ev } from './helpers/event-fixtures'

let server: DurableStreamTestServer
let baseUrl: string
let stream: DurableStream
let doneBodies: Array<any>
let config: ProcessWakeConfig
const streamPath = `/streams/review`
const callback = `http://callback.test/wake`

async function sourceOffset() {
  const head = await stream.head()
  if (!head.exists || !head.offset) throw new Error(`Fixture stream missing`)
  return head.offset
}

function deferred<T = void>() {
  let resolve!: (value: T) => void
  const promise = new Promise<T>((r) => {
    resolve = r
  })
  return { promise, resolve }
}

function notification(offset: string, epoch = 1): WebhookNotification {
  return {
    consumerId: `review`,
    epoch,
    wakeId: `review-${epoch}`,
    streamPath,
    streams: [{ path: streamPath, offset }],
    callback,
    claimToken: `test`,
    entity: {
      type: `review`,
      url: `/review/entity`,
      status: `active`,
      streams: { main: streamPath },
    },
  }
}

beforeEach(async () => {
  clearRegistry()
  server = new DurableStreamTestServer({ port: 0 })
  baseUrl = await server.start()
  stream = await DurableStream.create({
    url: `${baseUrl}${streamPath}`,
    contentType: `application/json`,
  })
  doneBodies = []
  const originalFetch = globalThis.fetch
  vi.spyOn(globalThis, `fetch`).mockImplementation(async (input, init) => {
    const url =
      typeof input === `string`
        ? input
        : input instanceof URL
          ? input.href
          : input.url
    if (url === callback) {
      const body = JSON.parse(String(init?.body))
      if (body.done) doneBodies.push(body)
      return Response.json({ ok: true, writeToken: `test` })
    }
    return originalFetch(input, init)
  })
  config = {
    baseUrl,
    idleTimeout: 0,
    heartbeatInterval: 1_000_000,
    rawInputRecovery: `bounded-checkpoint-v1`,
  }
})

afterEach(async () => {
  vi.restoreAllMocks()
  await server.stop()
})

it(`does not acknowledge B arriving after the delivered A delta`, async () => {
  const entered = deferred<any>()
  const release = deferred()
  const delivered: Array<Array<string>> = []
  defineEntity(`review`, {
    handler: async (ctx) => {
      delivered.push(
        ctx.events.filter((e) => e.type === `inbox`).map((e) => String(e.key))
      )
      entered.resolve(ctx)
      await release.promise
      ctx.replyText(`completed only A`)
      ctx.sleep()
    },
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
  )
  const aOffset = await sourceOffset()
  const activation = processWake(notification(aOffset), config)
  const ctx = await entered.promise
  await stream.append(
    JSON.stringify(ev(`inbox`, `b`, `insert`, { payload: `B` }))
  )
  const bOffset = await sourceOffset()
  await vi.waitFor(() => expect(ctx.db.collections.inbox.has(`b`)).toBe(true))
  release.resolve()
  await activation
  const history = await (await stream.stream({ live: false })).json<any>()
  console.log(
    `LIVE_ACK_REPRO`,
    JSON.stringify({
      aOffset,
      bOffset,
      delivered,
      doneBodies,
      types: history.map((e) => e.type),
    })
  )
  expect(delivered).toEqual([[`a`]])
  expect(history.some((e) => e.type === `runtime_checkpoint`)).toBe(false)
  expect(doneBodies[0].acks).toEqual([])
}, 10_000)

it(`does not rerun completed raw input on an explicit wakeEvent redelivery`, async () => {
  const delivered: Array<string> = []
  defineEntity(`review`, {
    handler: (_ctx, wake) => {
      delivered.push(String(wake.payload))
    },
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
  )
  const aOffset = await sourceOffset()
  await processWake(notification(aOffset), config)
  const history = await (await stream.stream({ live: false })).json<any>()
  expect(history.some((e) => e.type === `runtime_checkpoint`)).toBe(true)
  const again = notification(aOffset, 2)
  again.wakeEvent = {
    source: `user`,
    type: `inbox`,
    payload: `A`,
    fromOffset: 0,
    toOffset: 0,
    eventCount: 1,
  }
  await expect(processWake(again, config)).rejects.toThrow(
    `out-of-log explicit wake`
  )
  expect(doneBodies.at(-1).acks).toEqual([])
  await processWake(notification(aOffset, 3), config)
  console.log(`EXPLICIT_WAKE_REPRO`, JSON.stringify({ delivered, doneBodies }))
  expect(delivered).toEqual([`A`])
}, 10_000)

it(`rejects an opaque new explicit hint but handles its canonical source notification`, async () => {
  const delivered: Array<string> = []
  defineEntity(`review`, {
    handler: (_ctx, wake) => {
      delivered.push(String(wake.payload))
    },
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
  )
  await processWake(notification(await sourceOffset()), config)
  await stream.append(
    JSON.stringify(ev(`inbox`, `b`, `insert`, { payload: `B` }))
  )
  const fresh = notification(await sourceOffset(), 2)
  fresh.wakeEvent = {
    source: `user`,
    type: `inbox`,
    payload: `B`,
    fromOffset: 0,
    toOffset: 0,
    eventCount: 1,
  }
  await expect(processWake(fresh, config)).rejects.toThrow(
    `out-of-log explicit wake`
  )
  expect(doneBodies.at(-1).acks).toEqual([])
  await processWake(notification(await sourceOffset(), 3), config)
  expect(delivered).toEqual([`A`, `B`])
}, 10_000)

it(`rejects a distinct out-of-log explicit wake at an old offset without acking it`, async () => {
  const delivered: Array<string> = []
  defineEntity(`review`, {
    handler: (_ctx, wake) => {
      delivered.push(String(wake.payload))
    },
  })
  await stream.append(
    JSON.stringify(ev(`inbox`, `a`, `insert`, { payload: `A` }))
  )
  const oldOffset = await sourceOffset()
  await processWake(notification(oldOffset), config)
  const outOfLog = notification(oldOffset, 2)
  outOfLog.wakeEvent = {
    source: `timer`,
    type: `wake`,
    payload: `different timer`,
    fromOffset: 0,
    toOffset: 0,
    eventCount: 1,
  }
  await expect(processWake(outOfLog, config)).rejects.toThrow(
    `out-of-log explicit wake`
  )
  expect(delivered).toEqual([`A`])
  expect(doneBodies.at(-1).acks).toEqual([])
}, 10_000)
