"""Summarize retained local samples without merging unlike measurement windows.

Write cells expose exact client measure timestamps. Other pinned client modes
do not: their resource samples use the outer client invocation, explicitly so
labelled. Socket deltas omit traffic before the first/after the last sample of
each connection and are lower bounds. RSS excludes the shared kernel page cache.
"""
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys


def check_clock(samples):
    """Compare paired clocks, including steps that reverse before the final sample."""
    tolerance_ms = 100
    result = dict(status="UNVERIFIED", tolerance_ms=tolerance_ms, samples=len(samples), discontinuities=[],
                  scope="Sampled wall/monotonic consistency only; unsampled intervals are not qualified.")
    if len(samples) < 2 or any("monotonic_ns" not in s for s in samples):
        return result
    first = samples[0]
    previous = first["monotonic_ns"] - 1
    for i, sample in enumerate(samples):
        wall_ns = (sample["unix_ms"] - first["unix_ms"]) * 1_000_000
        mono_ns = sample["monotonic_ns"] - first["monotonic_ns"]
        drift_ms = (wall_ns - mono_ns) / 1_000_000
        if abs(drift_ms) > tolerance_ms or sample["monotonic_ns"] <= previous:
            result["discontinuities"].append(dict(sample_index=i, unix_ms=sample["unix_ms"],
                wall_delta_ms=wall_ns/1_000_000, monotonic_delta_ms=mono_ns/1_000_000, offset_drift_ms=drift_ms))
        previous = sample["monotonic_ns"]
    result["status"] = "INVALID" if result["discontinuities"] else "STABLE"
    return result


def kernel_fsync_event(line):
    """Linux x86-64 raw tracepoint export. Discard unused argument registers.

    perf script --ns --show-lost-events -F trace:pid,tid,time,event,trace
    Unknown/lost records invalidate the capture; never echo their raw contents.
    """
    match = re.fullmatch(r"\s*(\d+)/(\d+)\s+(\d+)\.(\d{9}):\s+raw_syscalls:sys_(enter|exit): NR (74|75) (.+)\s*", line.rstrip())
    if match is None:
        raise ValueError("invalid kernel fsync event")
    pid, tid, seconds, nanos, phase, call, detail = match.groups()
    row = dict(pid=int(pid), tid=int(tid), monotonic_ns=int(seconds)*1_000_000_000+int(nanos),
               phase=phase, syscall="fsync" if call == "74" else "fdatasync")
    if phase == "enter":
        fields = re.fullmatch(r"\(([0-9a-f]+),[^\n]*\)", detail)
        if fields is None:
            raise ValueError("invalid kernel fsync event")
        row["fd"] = int(fields[1], 16)
    else:
        fields = re.fullmatch(r"= (-?\d+)", detail)
        if fields is None:
            raise ValueError("invalid kernel fsync event")
        row["result"] = int(fields[1])
    return row


def summarize_kernel_fsync(events):
    pending, successful, errors, slow = {}, [], {}, []
    started = matched = unmatched = 0
    for row in events:
        thread = (row["pid"], row["tid"])
        if row["phase"] == "enter":
            if thread in pending:
                raise ValueError("overlapping kernel fsync calls")
            pending[thread] = row
            started += 1
            continue
        if row["phase"] != "exit":
            raise ValueError("invalid kernel fsync phase")
        entry = pending.pop(thread, None)
        if entry is None:
            unmatched += 1
            continue
        if row["syscall"] != entry["syscall"] or row["monotonic_ns"] < entry["monotonic_ns"]:
            raise ValueError("kernel fsync pairing/clock mismatch")
        matched += 1
        ns = row["monotonic_ns"]-entry["monotonic_ns"]
        if row["result"]:
            label = str(row["result"])
            errors[label] = errors.get(label, 0)+1
        else:
            successful.append(ns)
            if ns >= 100_000_000 and len(slow) < 64:
                slow.append(dict(pid=row["pid"], tid=row["tid"], syscall=row["syscall"],
                    start_monotonic_ns=entry["monotonic_ns"], elapsed_ns=ns))
    successful.sort()
    n = len(successful)
    return dict(started=started, matched=matched, unmatched_exits=unmatched, incomplete=list(pending.values()),
        errors=errors, first_64_slow_calls=slow,
        successful=dict(count=n, total_ns=sum(successful), p50_ns=successful[(n+1)//2-1],
            p99_ns=successful[(n*99+99)//100-1], max_ns=successful[-1],
            at_least_100ms=sum(ns >= 100_000_000 for ns in successful)) if n else None,
        scope="Matched per-thread kernel fsync/fdatasync tracepoints in the whole capture, including setup/drain. "
              "Incomplete boundaries are not durations. Wall time includes kernel work, blocking and descheduling, "
              "not pure device latency; tracing still perturbs execution. Unused argument registers are omitted "
              "from the exported events; the raw capture remains local-only.")


def summarize_fsync_trace(lines):
    """strace -f -qq -ttt -T, filtered to fsync/fdatasync; failures stay explicit."""
    pending, successful, failures = {}, [], {}
    started = completed = resumed_without_start = 0
    for number, line in enumerate(lines, 1):
        match = re.fullmatch(r"\s*(\d+)\s+\d+\.\d+\s+(.+)\s*", line.rstrip())
        if not match:
            raise ValueError(f"unrecognized fsync trace line {number}")
        tid, call = match.groups()
        kind = re.search(r"(fsync|fdatasync)(?:\(| resumed>)", call)
        if kind is None:
            raise ValueError(f"unrecognized fsync call on line {number}")
        kind = kind[1]
        if "<unfinished ...>" in call:
            if tid in pending:
                raise ValueError(f"overlapping calls on line {number}")
            pending[tid] = kind
            started += 1
            continue
        if call.startswith("<..."):
            original = pending.pop(tid, None)
            if original is None:
                resumed_without_start += 1
            elif original != kind:
                raise ValueError(f"resumed syscall mismatch on line {number}")
        else:
            if tid in pending:
                raise ValueError(f"missing resume on line {number}")
            started += 1
        result = re.search(r"= (-?\d+)(?: ([A-Z][A-Z0-9]+) .*)?\s+<(\d+)\.(\d{6})>$", call)
        if result is None:
            raise ValueError(f"missing fsync result/duration on line {number}")
        status, error, seconds, fraction = result.groups()
        completed += 1
        if status == "0":
            successful.append(int(seconds)*1_000_000+int(fraction))
        else:
            label = error or f"return_{status}"
            failures[label] = failures.get(label, 0)+1
    successful.sort()
    n = len(successful)
    return dict(started=started, completed=completed, incomplete_by_tid=pending,
        resumed_without_start=resumed_without_start, errors=failures,
        successful=dict(count=n, total_us=sum(successful),
            mean_us=sum(successful)/n, p50_us=successful[(n*50+99)//100-1],
            p99_us=successful[(n*99+99)//100-1], max_us=successful[-1],
            at_least_100ms=sum(us >= 100_000 for us in successful)) if n else None,
        scope="All traced filesystem fsync/fdatasync calls, including setup and drain. "
              "Elapsed syscall time includes ptrace perturbation and OS scheduling, not pure device latency. "
              "Failed and unfinished calls are not successful durability; not an unperturbed capacity result.")


def summarize_sync_timings(values, begin, end):
    keys = ("count", "calls", "total_ns")
    reset = any(any(b[k] < a[k] for k in keys) for a, b in zip(values, values[1:]))
    result = dict(counter_reset_detected=reset, observations=len(values),
                  whole_invocation=None if reset else values[-1], sampled_window=None)
    inside = [v for v in values if begin <= v["unix_ms"] <= end]
    if not reset and len(inside) >= 2:
        first, last = inside[0], inside[-1]
        result["sampled_window"] = dict(start_unix_ms=first["unix_ms"], end_unix_ms=last["unix_ms"],
                                       **{k:last[k]-first[k] for k in keys})
    return result


def summarize_phase_timings(observations, begin, end):
    """Difference cumulative counters; never sum successive cumulative samples."""
    phases = {}
    for observation in observations:
        stats = observation["cumulative"]
        assert sum(stats["buckets"]) == stats["count"], "inconsistent timing histogram"
        phases.setdefault(observation["phase"], []).append(observation)
    result = {}
    for phase, values in phases.items():
        reset = any(any(b["cumulative"][k] < a["cumulative"][k] for k in ("count", "total_ns", "bytes"))
                    for a, b in zip(values, values[1:]))
        row = dict(counter_reset_detected=reset, observations=len(values),
                   whole_invocation=None if reset else values[-1]["cumulative"], sampled_window=None)
        inside = [v for v in values if begin <= v["unix_ms"] <= end]
        if not reset and len(inside) >= 2:
            first, last = inside[0], inside[-1]
            delta = {k:last["cumulative"][k]-first["cumulative"][k] for k in ("count", "total_ns", "bytes")}
            delta["buckets"] = [b-a for a,b in zip(first["cumulative"]["buckets"], last["cumulative"]["buckets"])]
            assert sum(delta["buckets"]) == delta["count"] and all(n >= 0 for n in delta["buckets"])
            # A lifetime maximum cannot be differenced into a window maximum.
            row["sampled_window"] = dict(start_unix_ms=first["unix_ms"], end_unix_ms=last["unix_ms"], **delta)
        result[phase] = row
    return result


def summarize_write_outcomes(values, begin, end):
    """Stage counts can overlap; do not add them into an HTTP failure total."""
    assert all(v["schema_version"] == 1 for v in values)
    reset = any(any(b["cumulative"].get(k, 0) < n for k, n in a["cumulative"].items())
                for a, b in zip(values, values[1:]))
    result = dict(counter_reset_detected=reset, observations=len(values),
                  whole_invocation=None if reset else values[-1]["cumulative"], sampled_window=None)
    inside = [v for v in values if begin <= v["unix_ms"] <= end]
    if not reset and len(inside) >= 2:
        first, last = inside[0], inside[-1]
        delta = {k:n-first["cumulative"].get(k, 0) for k,n in last["cumulative"].items()}
        result["sampled_window"] = dict(start_unix_ms=first["unix_ms"], end_unix_ms=last["unix_ms"], cumulative_delta=delta)
    return result


def summarize_progress(samples, begin, end):
    nodes, groups = {}, {}
    for sample in samples:
        for observation in sample.get("replicas", []):
            when = observation["end_unix_ms"]
            if not begin <= observation["unix_ms"] <= when <= end:
                continue
            node = str(observation["node"])
            row = nodes.setdefault(node, dict(heads=[], errors=0))
            if "sampled_stream_indices" in observation:
                for key in ("sampled_stream_indices", "total_streams"):
                    assert row.setdefault(key, observation[key]) == observation[key], "HEAD sample domain changed"
            if "sampled_stream_names" in observation:
                assert row.setdefault("sampled_stream_names", observation["sampled_stream_names"]) == observation["sampled_stream_names"], "HEAD stream names changed"
            row["errors"] += int("error" in observation or observation.get("head_status") != 200)
            if "committed_bytes" in observation:
                row["heads"].append(dict(unix_ms=when, bytes=observation["committed_bytes"],
                                        collection_ms=when-observation["unix_ms"]))
            for group, metrics in enumerate(observation.get("groups", [])):
                if metrics.get("last_log_index") is None or metrics.get("last_applied") is None:
                    continue
                lag = metrics["last_log_index"]-metrics["last_applied"]["index"]
                state = groups.setdefault(f"{node}/{group}", dict(unapplied_entries=[], matched_gap_entries=[], snapshots=set()))
                state["unapplied_entries"].append(lag)
                for matched in (metrics.get("replication") or {}).values():
                    if matched is not None:
                        state["matched_gap_entries"].append(metrics["last_log_index"]-matched["index"])
                snapshot = metrics.get("snapshot")
                if snapshot is not None:
                    state["snapshots"].add(snapshot["index"])
    for row in nodes.values():
        heads = row.pop("heads")
        row["samples"] = len(heads)
        if heads:
            row.update(first=heads[0], last=heads[-1], max_collection_ms=max(h["collection_ms"] for h in heads))
        if len(heads) >= 2:
            seconds = (heads[-1]["unix_ms"]-heads[0]["unix_ms"])/1000
            if seconds > 0:
                row["committed_bytes_per_second"] = (heads[-1]["bytes"]-heads[0]["bytes"])/seconds
    for state in groups.values():
        for key in ("unapplied_entries", "matched_gap_entries"):
            values = state[key]
            state[key] = dict(samples=len(values), first=values[0], last=values[-1],
                              minimum=min(values), maximum=max(values)) if values else None
        state["observed_snapshot_indices"] = sorted(state.pop("snapshots"))
    return dict(nodes=nodes, groups=groups,
        scope="Committed HEAD byte rates between individual observation completions, not exact client-window acks. "
              "Bytes cover only declared sampled stream indices, with no extrapolation to total streams. "
              "Raft entry gaps are not commands or bytes, and last_log_index is not a commit index. "
              "Sequential node samples cannot establish an instantaneous cross-node gap. Missed peaks are possible.")


def summarize(directory):
    root = Path(directory)
    provenance = json.loads((root / "provenance.json").read_text())
    rows = []
    for result_file in sorted(root.glob("*/result.json")):
        cell = result_file.parent
        result = json.loads(result_file.read_text())
        client_file = cell / "client.json"
        raw = json.loads(client_file.read_text()) if client_file.exists() and client_file.stat().st_size else {}
        row = dict(cell=cell.name, arm=result["arm"], workload=result["workload"], profile=result["profile"],
                   verdict=result["verdict"], error=result.get("error"), raw_client=raw)
        outer = result.get("client_window",{})
        begin = raw.get("measure_start_unix_ms",outer.get("start_unix_ms",0))
        end = raw.get("measure_end_unix_ms",outer.get("end_unix_ms",0))
        row["sample_window"] = dict(start_unix_ms=begin,end_unix_ms=end,
            scope="exact client measurement" if "measure_start_unix_ms" in raw else "outer client invocation; includes non-measure work")
        nodes = set(map(str,result.get("node_pids",[])))
        first, last, sockets = {}, {}, {}
        peaks = dict(sut_rss_bytes=0,client_rss_bytes=0)
        window = []
        progress = []
        observations = []
        samples = cell / "samples.jsonl.gz"
        if samples.exists():
            with gzip.open(samples,"rt") as file:
                for line in file:
                    sample = json.loads(line)
                    observations.append(sample)
                    if not begin <= sample["unix_ms"] <= end:
                        continue
                    window.append(sample)
                    if "replicas" in sample:
                        progress.append(sample)
                    for pid, process in sample["processes"].items():
                        first.setdefault(pid,process)
                        last[pid] = process
                    for name, selected in [("sut_rss_bytes",nodes),("client_rss_bytes",{str(result.get("client_pid"))})]:
                        value = sum(p["rss_pages"]*provenance["page_bytes"] for pid,p in sample["processes"].items() if pid in selected)
                        peaks[name] = max(peaks[name],value)
                    for socket in sample["sockets"]:
                        if socket["replication"]:
                            key = (socket["local"],socket["peer"],tuple(socket["owners"]))
                            sent = socket["counters"].get("bytes_sent",0)
                            initial, maximum = sockets.setdefault(key,(sent,sent))
                            sockets[key] = (initial,max(maximum,sent))
        row["clock_integrity"] = check_clock(observations)
        clock_stable = row["clock_integrity"]["status"] == "STABLE"
        resources = dict(peak_sampled=peaks,samples=len(window),
                         observed_replication_sent_bytes_lower_bound=sum(b-a for a,b in sockets.values()))
        if clock_stable and len(window) >= 2:
            seconds = (window[-1]["monotonic_ns"]-window[0]["monotonic_ns"])/1_000_000_000
            resources.update(sampled_seconds=seconds,
                average_sut_cpu_cores=sum(last[p]["cpu_ticks"]-first[p]["cpu_ticks"] for p in nodes if p in first)/provenance["cpu_hz"]/seconds,
                sut_write_bytes=sum(last[p]["io"]["write_bytes"]-first[p]["io"]["write_bytes"] for p in nodes if p in first),
                sut_read_bytes=sum(last[p]["io"]["read_bytes"]-first[p]["io"]["read_bytes"] for p in nodes if p in first))
        row["resources"] = resources
        trace = cell / "fsync-trace.log.gz"
        if trace.exists():
            with gzip.open(trace, "rt") as file:
                row["fsync_trace"] = summarize_fsync_trace(file)
        if not clock_stable:
            # Keep original executions/counters, but do not align rates or phase
            # windows against a clock that jumped (or was never observed).
            begin, end = 1, 0
        if result.get("progress_sampling"):
            row["progress"] = summarize_progress(progress, begin, end)
            row["drain"] = result.get("drain")
        storage_file = cell / "storage-bytes.json"
        if storage_file.exists():
            storage = json.loads(storage_file.read_text())
            row["final_storage_bytes"] = dict(total=sum(storage.values()),
                wal=sum(v for k,v in storage.items() if k.endswith(".wal")),
                snapshots=sum(v for k,v in storage.items() if Path(k).name.startswith("snapshot-")))
        if result.get("diagnostics"):
            # Both pinned engines print WAL deltas divided by the CONFIGURED
            # interval (exactly 1s here), so these sums recover counter totals.
            # SRV_STATS uses actual elapsed time instead: do not sum its rates
            # and call them append counts. Use the client's all-phase acks.
            staged, syncs = 0, 0
            phase_timings = {}
            sync_timings = {}
            write_outcomes = {}
            for log in cell.glob("node-*.log.gz"):
                observations = []
                sync_observations = []
                outcome_observations = []
                with gzip.open(log, "rt") as file:
                    for line in file:
                        match = re.search(r"WAL_CONT staged/s=(\d+) fsync/s=(\d+)", line)
                        if match:
                            staged += int(match[1])
                            syncs += int(match[2])
                        if line.startswith("RAFT_TIMING "):
                            observations.append(json.loads(line.removeprefix("RAFT_TIMING ")))
                        if line.startswith("WAL_SYNC "):
                            sync_observations.append(json.loads(line.removeprefix("WAL_SYNC ")))
                        if line.startswith("RAFT_WRITE_OUTCOMES "):
                            outcome_observations.append(json.loads(line.removeprefix("RAFT_WRITE_OUTCOMES ")))
                if observations:
                    phase_timings[log.name] = summarize_phase_timings(observations, begin, end)
                if sync_observations:
                    sync_timings[log.name] = summarize_sync_timings(sync_observations, begin, end)
                if outcome_observations:
                    write_outcomes[log.name] = summarize_write_outcomes(outcome_observations, begin, end)
            if write_outcomes:
                row["write_outcomes"] = dict(nodes=write_outcomes,
                    scope="Process-wide command-stage counters, including internal metadata; not HTTP wire acknowledgements. "
                          "Stage counts overlap: a response timeout can precede durable apply. Sampled windows are "
                          "first/last observations INSIDE the client window, not exact client boundaries. Missing is not zero.")
            if phase_timings:
                row["phase_timings"] = dict(nodes=phase_timings,
                    scope="Cumulative completed-attempt wall times, including setup/warmup for whole_invocation. "
                          "Sampled windows use first/last observations INSIDE the client window, not exact client boundaries. "
                          "Nested/overlapping phases are NOT additive CPU or pure fsync syscall time.")
            if sync_timings:
                row["sync_timings"] = dict(nodes=sync_timings,
                    scope="Successful synchronous covering WAL-fsync loops only, before durability notification. "
                          "A loop can sync multiple segments. Wall time includes OS descheduling, not pure disk or CPU time. "
                          "Cumulative whole-invocation totals include setup/warmup; sampled windows are first/last observations "
                          "inside client bounds. The unmodified upstream binary has no such probe; missing is not zero.")
            acknowledgements = raw.get("ok_total_all_phases")
            row["wal_diagnostics"] = dict(staged_records=staged, fsyncs=syncs,
                client_acks_all_phases=acknowledgements,
                fsyncs_per_ack=syncs/acknowledgements if acknowledgements else None,
                records_per_ack=staged/acknowledgements if acknowledgements else None,
                final_counter_interval_captured=result.get("diagnostic_tail_captured", result["verdict"] == "PASS"),
                scope="aggregate native WAL counters over whole invocation, including setup/warmup; not measure-window or all filesystem fsyncs. "
                      "Ratios omitted when the pinned client does not report all-phase append counts (including seed). "
                      "If final_counter_interval_captured is false, counters and ratios are lower bounds only.")
        rows.append(row)
    output = dict(provenance_sha256=hashlib.sha256((root/"provenance.json").read_bytes()).hexdigest(),
                  analyzer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), rows=rows,
                  scope="single-host resource qualification; profile cells are perturbed and never capacity rows")
    (root/"summary.json").write_text(json.dumps(output,indent=2)+"\n")
    for row in rows:
        if not row["profile"]:
            resource = row["resources"]
            print(row["arm"],row["workload"],row["verdict"],
                  "clock",row["clock_integrity"]["status"],
                  "cpu",round(resource["average_sut_cpu_cores"],2) if "average_sut_cpu_cores" in resource else "unqualified",
                  "RSS MiB",round(resource["peak_sampled"]["sut_rss_bytes"]/2**20,1),
                  "replication MiB lower bound",round(resource["observed_replication_sent_bytes_lower_bound"]/2**20,1))


if __name__ == "__main__":
    summarize(sys.argv[1])
