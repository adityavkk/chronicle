"""Harness regressions only; real MinIO cells provide the integration evidence."""
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from botocore.exceptions import ClientError
from cold_faults import ColdLab
from lab import Lab


class StartupS3:
    def __init__(self, delays=0, error=None, create_unknown=False):
        self.delays, self.error, self.create_unknown = delays, error, create_unknown
        self.buckets = set()

    def list_buckets(self):
        if self.error or self.delays:
            self.delays -= 1
            raise ClientError({"Error": {"Code": self.error or "XMinioServerNotInitialized"}}, "ListBuckets")
        return {"Buckets": []}

    def create_bucket(self, Bucket):
        if self.error:
            raise ClientError({"Error": {"Code": self.error}}, "CreateBucket")
        if self.delays:
            raise ClientError({"Error": {"Code": "XMinioServerNotInitialized"}}, "CreateBucket")
        self.buckets.add(Bucket)
        if self.create_unknown:
            self.create_unknown = False
            raise TimeoutError("response lost after mutation")


class StorageReadiness(unittest.TestCase):
    def test_delayed_object_layer_is_ready_before_bucket_creation(self):
        for delays in (0, 1, 3):
            with self.subTest(delays=delays), tempfile.TemporaryDirectory() as directory:
                provider = StartupS3(delays=delays)
                lab = SimpleNamespace(s3=provider, bucket="fixture", output=Path(directory), wait=Lab.wait)
                ColdLab.create_bucket(lab)
                self.assertEqual(provider.buckets, {"fixture"})

    def test_permanent_read_errors_and_unknown_mutations_are_not_retried(self):
        for code in ("AccessDenied", "InvalidAccessKeyId", "InternalError"):
            with self.subTest(code=code), tempfile.TemporaryDirectory() as directory:
                provider = StartupS3(error=code)
                lab = SimpleNamespace(s3=provider, bucket="fixture", output=Path(directory), wait=Lab.wait)
                with self.assertRaises(ClientError):
                    ColdLab.create_bucket(lab)
                self.assertEqual(provider.buckets, set())
        with tempfile.TemporaryDirectory() as directory:
            provider = StartupS3(create_unknown=True)
            lab = SimpleNamespace(s3=provider, bucket="fixture", output=Path(directory), wait=Lab.wait)
            with self.assertRaises(TimeoutError):
                ColdLab.create_bucket(lab)
            self.assertEqual(provider.buckets, {"fixture"})


if __name__ == "__main__":
    unittest.main()
