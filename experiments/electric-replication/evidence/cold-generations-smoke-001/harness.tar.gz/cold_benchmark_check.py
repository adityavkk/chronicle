"""Independent checks for cold benchmark evidence, not a server implementation.

An S3 GET is not automatically a client read. Only immutable, fully published
preconditioning keys, during an otherwise quiescent client invocation, qualify.
New-key verification, inventories, recovery and probes are excluded. No request
spanning a window boundary is assigned an invented partial byte count.
"""
from collections import Counter
import gzip
import json
from pathlib import Path
import re
import statistics
import sys

from benchmark_summary import check_clock


def read_lines(path):
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt") as source:
        return [json.loads(line) for line in source if line.strip()]


def listing_key(key, native):
    # object_store 0.11.2 Path::from encodes ~, preserves +, then the S3
    # transport URL-encodes again. Restrict to this harness's generated grammar;
    # never recursively unquote opaque keys (a%7Eb and a~b are different).
    if not re.fullmatch(r"[A-Za-z0-9_+./~-]+", key) or any(not p or p in (".","..") for p in key.split("/")):
        raise ValueError("key outside the benchmark's canonical grammar")
    return key.replace("~","%7E") if native else key


def object_window(events, start, end, client_keys):
    if end <= start:
        raise ValueError("invalid measurement window")
    methods, statuses = Counter(), Counter()
    client_bytes = client_gets = uploaded = downloaded = boundary = errors = 0
    for event in events:
        if event.get("op") != "s3":
            if start <= event["time_ns"] <= end:
                errors += 1
            continue
        if event["time_ns"] < event["start_ns"]:
            raise ValueError("object clock reversed")
        if event["time_ns"] < start or event["start_ns"] > end:
            continue
        if event["start_ns"] < start or event["time_ns"] > end:
            boundary += 1
            continue
        method, status = event["method"], event["status"]
        methods[method] += 1
        statuses[str(status)] += 1
        uploaded += event["request_bytes"]
        downloaded += event["bytes"]
        # A missing object HEAD is part of upstream offload existence checks.
        if status >= 400 and not (method == "HEAD" and status == 404):
            errors += 1
        if method == "GET" and status in (200, 206) and event["path"] in client_keys:
            client_gets += 1
            client_bytes += event["bytes"]
    return dict(methods=dict(methods), statuses=dict(statuses), request_body_bytes=uploaded,
                response_body_bytes=downloaded, client_payload_gets=client_gets,
                client_remote_fetched_bytes=client_bytes, boundary_requests_excluded=boundary,
                errors=errors, scope="whole completed S3 requests inside client invocation; remote fetch bytes, not HTTP emitted bytes")


def validate(result, raw, objects, samples):
    errors = []
    clock = check_clock(samples)
    if clock["status"] != "STABLE":
        errors.append("unstable or insufficient paired clock samples")
    if result.get("client_exit_code") != 0:
        errors.append("client did not exit successfully")
    workload = result["workload"]
    counts = [raw[k] for k in ("counts", "write_counts", "read_counts", "append_counts") if k in raw]
    if not counts or any(c["other_err"] or c["backpressure"] for c in counts):
        errors.append("client errors or rejections; not a zero-error operating point")
    if raw.get("subscriber_errors", 0) or raw.get("lazy_creates", 0):
        errors.append("subscriber errors or lazy stream creation")
    if not result.get("drain") or not all(r["bytes"] == result["target_bytes"] for r in result["drain"]):
        errors.append("all-replica committed drain mismatch")
    if len(result.get("drain", [])) != result["replicas"]:
        errors.append("missing replica drain")
    if result.get("drain") and any(r["offsets"]!=result["drain"][0]["offsets"] for r in result["drain"]):
        errors.append("replicas disagree on per-stream committed offsets")
    probes = result.get("probes", [])
    if len(probes) != result["replicas"] * result["streams"]:
        errors.append("missing independent byte probes")
    if any(p["sha256"] != p["expected_sha256"] or p["offset"] != p["bytes"] for p in probes):
        errors.append("byte/offset mismatch")
    if workload == "replay" and raw.get("bytes_read_total") != raw["counts"]["ok"] * result["seed_bytes"]:
        errors.append("replay totals disagree with independently seeded bytes")
    if result.get("sampling_error"):
        errors.append("resource sampler failed")
    start, end = result["client_window"]["start_ns"], result["client_window"]["end_ns"]
    evidence = object_window(objects, start, end, set(result.get("client_object_keys", [])))
    if evidence["errors"]:
        errors.append("object service errors or unknowns in measurement window")
    if result["cold"]:
        pre = result["precondition"]
        if not pre["remote_keys"] or pre["local_payload_bytes"] or pre["local_segment_bytes"]:
            errors.append("cold precondition did not reclaim all seeded local payload")
        mapped = {listing_key(key,result["arm"]=="native") for key in pre["remote_keys"]}
        if mapped != set(pre["listing_keys"]):
            errors.append("published manifest does not match actual object keys")
        expected_keys={"/"+result["object_bucket"]+"/"+key for key in mapped} if result["seed_bytes"] else set()
        if expected_keys != set(result["client_object_keys"]):
            errors.append("client attribution contains keys outside its immutable precondition")
        if workload in ("replay", "mixed") and not evidence["client_remote_fetched_bytes"]:
            errors.append("no attributable client cold-read bytes in measurement")
    elif evidence["client_remote_fetched_bytes"]:
        errors.append("hot control unexpectedly used cold objects")
    return dict(verdict="FAIL" if errors else "PASS", errors=errors, clock=clock, objects=evidence)


def resources(samples, window, roles, cpu_hz, page_bytes):
    selected = [s for s in samples if window["start_ns"] <= s["monotonic_ns"] <= window["end_ns"]]
    out = {}
    for role, pids in roles.items():
        values = []
        for s in selected:
            observations = [s["processes"][str(pid)] for pid in pids if str(pid) in s["processes"]]
            if len(observations) == len(pids):
                values.append((s["monotonic_ns"], observations))
        if len(values) < 2:
            out[role] = dict(status="INSUFFICIENT", complete_samples=len(values))
            continue
        seconds = (values[-1][0] - values[0][0])/1e9
        first, last = values[0][1], values[-1][1]
        out[role] = dict(status="MEASURED", complete_samples=len(values), sampled_seconds=seconds,
            cpu_cores=sum(b["cpu_ticks"]-a["cpu_ticks"] for a,b in zip(first,last))/cpu_hz/seconds,
            peak_rss_bytes=max(sum(p["rss_pages"] for p in ps)*page_bytes for _,ps in values),
            io_delta={k:sum(b["io"][k]-a["io"][k] for a,b in zip(first,last)) for k in first[0]["io"]})
    return out


def summarize(root):
    rows = []
    for path in sorted(Path(root).glob("*/result.json")):
        row = json.loads(path.read_text())
        raw_path = path.parent/"client.json"
        if not raw_path.exists() or not row.get("client_window"):
            rows.append(dict(cell=path.parent.name, verdict="FAIL", error=row.get("error")))
            continue
        try:
            raw = json.loads(raw_path.read_text())
        except json.JSONDecodeError:
            rows.append(dict(cell=path.parent.name, verdict="FAIL", error="no valid client output"))
            continue
        objects = [e for p in sorted(path.parent.glob("objects-*.jsonl.gz")) for e in read_lines(p)]
        samples = read_lines(path.parent/"samples.jsonl.gz")
        checked = validate(row,raw,objects,samples)
        # Never turn an earlier failed assertion into a clean run.
        if row["verdict"] != "PASS":
            checked["verdict"] = "FAIL"
            checked["errors"].append(row.get("error", "driver failed"))
        counts = raw.get("counts",raw.get("write_counts",raw.get("append_counts")))
        latency = raw.get("latency_ms",raw.get("write_latency_ms",raw.get("fan_out_latency_ms",{})))
        secs = raw.get("drive_secs",raw.get("elapsed_secs"))
        rows.append(dict(cell=path.parent.name,arm=row["arm"],cold=row["cold"],workload=row["workload"],
            repetition=row["repetition"],verdict=checked["verdict"],errors=checked["errors"],
            counts=counts,ops_per_sec=raw.get("aggregate_ops_per_sec",counts["ok"]/secs),
            bytes_per_sec=raw.get("bytes_per_sec"),latency=latency,
            write_latency=raw.get("write_latency_ms"),read_latency=raw.get("read_latency_ms"),
            objects=checked["objects"],resources=resources(samples,row["client_window"],row["roles"],row["cpu_hz"],row["page_bytes"]),
            drain_seconds=row.get("drain_seconds"),sequence=row.get("sequence"),
            precondition=row.get("precondition"),after_client=row.get("after_client")))
    groups = {}
    for row in rows:
        if "arm" in row:
            groups.setdefault((row["arm"],row["cold"],row["workload"]),[]).append(row)
    aggregates = []
    for (arm,cold,workload),cells in groups.items():
        valid = [r for r in cells if r["verdict"] == "PASS"]
        aggregates.append(dict(arm=arm,cold=cold,workload=workload,cells=len(cells),passed=len(valid),
            median_ops_per_sec=statistics.median(r["ops_per_sec"] for r in valid) if valid else None,
            min_ops_per_sec=min((r["ops_per_sec"] for r in valid),default=None),
            max_ops_per_sec=max((r["ops_per_sec"] for r in valid),default=None)))
    result=dict(cells=rows,aggregates=aggregates,passed=sum(r["verdict"]=="PASS" for r in rows),total=len(rows))
    (Path(root)/"summary.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(dict(passed=result["passed"],total=result["total"],aggregates=aggregates),indent=2))
    return result


if __name__ == "__main__":
    result = summarize(sys.argv[1])
    raise SystemExit(0 if result["total"] and result["passed"] == result["total"] else 1)
